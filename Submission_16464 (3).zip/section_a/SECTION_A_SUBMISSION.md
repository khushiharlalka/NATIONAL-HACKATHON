# Candidate Submission – Section A: Event Correlation and Routing

**Candidate ID:** 16464  
**Chosen programming language(s):** Python 3.10+ for both problems. Standard library only.  
**Submission repository/path:** `section_a/` → `SECTION_A_SUBMISSION.md`, `incident_detection.py`, `route_planner.py`, `sample_events.txt`, `screenshots/`  
**Setup command:** none (standard library only; Python 3.10+)  
**Problem 1 commands:** `python3 incident_detection.py --test` → 18 tests OK; `python3 incident_detection.py < sample_events.txt`  
**Problem 2 commands:** `python3 route_planner.py --test` → 15 tests OK; `python3 route_planner.py --demo`

## Section A – Event Correlation and Routing

### Problem 1 algorithm

**Source:** `incident_detection.py`. The input starts with the number of deliveries, followed by one whitespace-delimited record per line in the order `event_id server_id timestamp event_type severity`. Output is a JSON array containing the earliest incident, or `[]`.

Use an event-time min-heap ordered by `(timestamp, event_id)` to reorder accepted deliveries. A set of IDs in the heap removes duplicates before they reach the sweeps. Process the ordered stream with separate 60,000 ms and 30,000 ms sweeps.

Windows are inclusive and have non-negative integer starts. For a window ending at `x` with duration `D`, an event at timestamp `t` enters at `max(D, t)` and expires at `t + D + 1`. At each boundary, apply all arrivals and expirations before evaluating a rule.

- **SERVER.** Maintain a frequency map of window event types per server, a deque of severity-5 events, and a count of equal adjacent critical types. Count all event types from that server toward the distinct-type requirement. Appending a critical event affects only the last pair. Removing the oldest critical event affects only the first pair. A server qualifies when its critical deque has at least five events, its map has at least three types, and its equal-pair count is zero.
- **CROSS_SERVER.** Keep the number of in-window critical events per server and remove zero counts. The window qualifies when at least four servers remain.
- **Output.** Take the earliest window from each sweep, then compare start timestamps. If starts tie, prefer SERVER and then the lexicographically smallest qualifying server ID. The SERVER witness contains all critical events from that server and the earliest additional events needed to witness three types. The CROSS_SERVER witness contains all critical events in the window and all affected server IDs in lexicographic order. Event IDs follow `(timestamp, event_id)` order.

### Correctness argument

The reorder heap releases a complete timestamp group only once that timestamp is strictly below the watermark. This prevents results from depending on arrival order within the permitted lateness. For a fixed duration, window membership changes only at an entry or expiry boundary. The counters match the window after processing all changes at that boundary. Since only changed servers can become eligible, checking those servers suffices to find the first SERVER window. Expiration can create the first match. For example, when the first of two adjacent equal critical types falls out of an otherwise qualifying window, the equal-pair count drops to zero. Each sweep evaluates window starts in increasing order, so comparing the first candidate from each sweep yields the global earliest start.

### Time complexity

Let `n` be deliveries, `B` the peak reorder-heap size, `A` the peak active 60-second window size, and `K` the number of servers in the first qualifying cross-server window, or zero if there is none. Expected time is `O(n log(B + 1) + K log(K + 1))` under normal hash-table behaviour. Each event is inserted and expired at most once per sweep. The `K log(K + 1)` term sorts the cross-server output IDs. With pathological hash collisions, the Python implementation has an `O(n²)` worst case. Using balanced trees for maps and sets would give `O(n log(n + 1))` deterministic worst-case time under constant-cost key comparisons.

### Space complexity

Working space is `O(B + A)`, plus the output. Peak space can reach `O(n)` when events are densely concentrated in a short time interval. Retention is bounded in event time by the five-minute reorder allowance and the longest active window of one minute. Deployments with a strict memory budget can store compact event records or use disk-backed state. The reference implementation keeps its state in memory and has not been load-tested at 10 million deliveries.

### Watermark and late-event policy

Set `W = maximum event timestamp observed − 300,000`. Accept timestamps at `W`. Drop and count deliveries strictly below `W` in a live implementation. The reference program drops them. Release buffered events and finalise window ends strictly below `W`. After release, any exact repeat of that event has a timestamp below `W`, so no permanent in-memory set of delivery IDs is needed. At end of input, flush the heap and remaining sweep boundaries.

**Parallelism.** Assign each server's events to the same partition for SERVER detection. Merge accepted critical streams for CROSS_SERVER detection and use the minimum of their input watermarks as the completion frontier. This includes windows spanning multiple partitions. Apply the specified lateness rule at ingress before partition fan-out if the contract is defined against a global maximum. For parallel CROSS_SERVER sweeps, give workers disjoint ranges of window starts and the corresponding 30-second look-ahead. A worker emits only starts it owns. Reduce candidate reports with the global tie-break rule. A live reducer can commit a candidate starting at `s` once its combined watermark is strictly greater than `s + 60,000`.

**Restart and replay.** Restore watermark, input offsets, pending events and sweep state from the same checkpoint. Persist the final result and its notification outbox entry in the same transaction with a unique key `(rule version, incident type, scope, start, end)`. Scope is a fixed global value for CROSS_SERVER and the server ID for SERVER. Keep this key stable across deliveries. Retries by the outbox publisher use the same key and the notification receiver deduplicates on it. Retain durable keys for the allowed replay period.

### Problem 2 algorithm

**Executable source:** `route_planner.py`. Use directed adjacency lists and assign each road a stable ID. Take a consistent snapshot of graph data and capacity calendars. The adjusted duration of an edge is `base_time × congestion_multiplier`. Assume positive durations, waiting at vertices, and the departure parameter as the earliest permissible start. Minimise arrival time, including any wait. A demand of `q` occupies `q` units over a half-open interval `[entry, exit)`. Two intervals that meet at an endpoint do not overlap.

Each road calendar represents consecutive segments of constant reserved usage. Examine the segment containing the candidate entry as well as subsequent segments. Capacity must suffice throughout the traversal.

```text
EARLIEST_ENTRY(road, ready, travel, demand, snapshot):
    entry = ready
    repeat:
        segment = first segment of road's calendar in snapshot that
                  intersects [entry, entry + travel)
                  and has usage + demand > road.capacity
        if no such segment:
            return entry
        if segment.end is infinity:
            return infinity
        entry = segment.end

PLAN(snapshot, source, destination, departure, demand):
    arrival[v] = infinity for each vertex v
    arrival[source] = departure
    parent = empty map
    queue = indexed min-priority queue, ordered by (arrival, vertex ID)
    queue.insert(source, departure)

    while queue is not empty:
        u = queue.extract_min()
        if u == destination:
            return reconstruct road IDs and [entry, exit) intervals from parent

        for each outgoing road e = (u, v) in road ID order:
            if e is closed or e.capacity < demand:
                continue
            travel = e.base_time * e.congestion_multiplier
            entry = EARLIEST_ENTRY(e, arrival[u], travel, demand, snapshot)
            if entry is infinity:
                continue
            exit = entry + travel
            if exit < arrival[v]:
                arrival[v] = exit
                parent[v] = (u, e.id, entry, exit, e.version)
                queue.insert_or_decrease(v, exit)

    return NO_ROUTE
```

If the first blocked segment overlaps a proposed fixed-duration traversal, moving its entry forward to any point before that segment ends still overlaps it. The jump to the end therefore skips no feasible time. On a static graph without reservations, Dijkstra is valid because weights are fixed and non-negative. With calendars on a snapshot, the earliest-arrival function for an edge is FIFO: a robot ready sooner may wait and take any slot available to a robot ready later. Therefore only the earliest arrival at each vertex needs to be retained. Any path that improved a settled destination would have to reach its first unsettled vertex earlier than that vertex's priority, contradicting relaxation from its settled predecessor.

A binary indexed heap gives `O((V + E) log V)` time for static planning and `O(V)` per-query workspace. Graph storage is `O(V + E)` plus calendar storage. With up to `M` calendar segments per relevant edge and `L` segments actually scanned, calendar work adds `O(E log(M + 1) + L)`. Seek once per edge and continue scanning forward after each blocked segment. Snapshot handles can share versioned storage. The SQLite reference instead rebuilds the adjacency lists and uses a lazy heap. Its graph search costs O(V + E log(E + 1)) time and O(V + E) space, plus calendar work. For a road with r bookings, rebuilding its usage segments costs O(r log(r + 1)) time and O(r) temporary space.

**Time-dependent duration.** For entry-dependent `d(e, t)`, relax using the minimum feasible value of `t + d(e, t)` over `t ≥ arrival[u]`. Availability and usage must allow the full interval. If the raw arrival function is FIFO, the earliest feasible entry suffices. For a non-FIFO profile with waiting permitted, examine later entries using a finite piecewise schedule or discrete time grid. The minimised arrival over feasible departures is FIFO as a function of readiness time. Without waiting under a non-FIFO profile, use a time-expanded graph or retain multiple labels.

**Alternatives.** A* can reduce search with an admissible time lower bound, for example straight-line distance divided by a verified network-wide maximum speed. If negative *costs* are allowed, Bellman–Ford handles a static graph and detects reachable negative cycles. A reachable negative cycle that can reach the destination makes the objective unbounded. Johnson reweighting can support repeated static queries without negative cycles. Negative physical durations are incompatible with road occupancy. At large scale, exact A* or an updatable routing index can reduce search. A restricted corridor or limited set of candidate routes can answer faster and can miss the global minimum. Expand the search when the approximation fails to find a feasible route.

### Dynamic update strategy

The runnable reference uses a local SQLite file and serializes writers with BEGIN IMMEDIATE. Each reservation performs the search and writes all intervals inside that transaction. This implements atomic capacity checks and retries by request ID across connections to the same database. The reference checks road versions and the first entry time before dispatch. It uses integer time ticks, recomputes calendars from bookings, and serializes all writes. It is intended for local verification. The per-road locking, indexed calendar, and road-admission design below describe the production approach.

Version road changes and publish them atomically with relevant calendar changes. Store request IDs uniquely, together with their request parameters and reservation status. The shared database is the authority for capacity across service instances.

```text
RESERVE(request_id, request):
    repeat up to configured retry limit:
        snapshot = open consistent read snapshot
        if request_id already has a committed reservation:
            return it if request parameters match, otherwise return ID_CONFLICT

        route = PLAN(snapshot, request fields)
        if route is NO_ROUTE:
            return NO_ROUTE for that snapshot

        begin transaction
        lock or create the unique request row
        if matching reservation is now committed:
            return it and commit the read
        if this ID belongs to different request parameters:
            rollback and return ID_CONFLICT

        lock each distinct road row used by route in ascending road ID order
        read the latest committed road states and calendars under those locks
        if a planned interval has already started, a road version changed,
           or adding all route intervals would exceed capacity at any point:
            rollback and retry with a fresh snapshot

        insert all reservations and mark the request RESERVED
        commit and return the reservation

    return RETRYABLE_CONFLICT
```

Every writer of a road or calendar, including closures, must follow the same road-lock protocol. No transaction holding a road lock may subsequently wait for a request lock. A capacity decrease cannot leave usable reservations above the new limit. Mark affected future reservations invalid or defer the decrease until active traversals clear. The transaction rechecks usage after taking locks, so two services cannot both commit a reservation for the same capacity-one slot. A failure on the last road rolls back the entire route. Retrying after a lost response returns the reservation already stored under the same ID.

Immediately before dispatch, validate the current reservation, future entry times, road versions and all allocated intervals. If invalid, cancel or replace the reservation and replan. Bind the robot's admission to a current reservation token checked at each road entry so a later closure can still block entry. The plan is optimal for its query snapshot and must be feasible when reserved and at dispatch. A change elsewhere can produce a better route in a later snapshot.

For exact static-route caches use source, destination, demand and graph version. For exact calendar-aware caches also include departure time and calendar version. An unchosen edge may improve, so validating only the edges of a cached route is insufficient to preserve optimality.

### Tests and edge cases

**Problem 1.** The source is `incident_detection.py` and the sample input is `sample_events.txt` (also shown under "Problem 1 sample input" below). Run from inside `section_a/`:

```bash
python3 incident_detection.py --test
python3 incident_detection.py < sample_events.txt
```

The first command runs 18 executable tests. They cover empty input, four critical events, a qualifying five-event sequence, only two types, equal neighbouring types, reverse ordering, duplicate events before and after watermark release, exact 30-second inclusion, exclusion at 30,001 ms, acceptance at the lateness boundary, rejection 1 ms behind it, expiry making a window valid, tied timestamps, type witnesses, competing window starts and deterministic incident ties. Randomised comparisons of 3,000 streams containing ties, out-of-order delivery and duplicates also matched direct window enumeration. The sample above returns `SERVER`, window `[40000, 100000]`, server `server-1` and events `e0, e1, e2, e3, e4` in that order.

**Problem 2.** Fifteen automated tests cover route optimality, directed reachability, closure, capacity, congestion, waiting, concurrency with independent SQLite connections, idempotency, rollback, and dispatch validation. The source is `route_planner.py`. Run from inside `section_a/`:

```bash
python3 route_planner.py --demo
python3 route_planner.py --test
```

The table includes scenarios for the runnable reference and additional production-design acceptance cases. All times use the same unit.

| # | Input or action | Expected outcome |
|---|---|---|
| 1 | Source equals destination, departure 8 | Empty route, arrival 8 |
| 2 | Only edge points from target to source | No route from source to target |
| 3 | Direct edge costs 10, alternate costs 3 + 4, depart 0 | Alternate, arrival 7 |
| 4 | Direct edge is closed | Use the fastest available alternative or report no route |
| 5 | Demand 3, fastest road capacity 2 | Exclude that road |
| 6 | Direct edge base 2, multiplier 4, alternate costs 6 | Alternate, arrival 6 from time 0 |
| 7 | Only edge has duration 3 and full booking on [0, 5) | Enter at 5 and arrive at 8 |
| 8 | Direct edge takes 4, booked on [0, 10). Free alternate takes 6 | Alternate, arrival 6 from time 0 |
| 9 | Capacity 1, bookings [0, 5) and [5, 10) | Both can commit |
| 10 | Capacity 3, active demands 1 and 2 in the same interval | Both can commit, any further positive demand must wait or replan |
| 11 | Two independent service instances race for one capacity-one slot | At most one reserves the contested slot |
| 12 | Eligibility changes on the last road before reservation commit | Roll back the full plan and retry |
| 13 | Road closes after reservation and before dispatch | Block dispatch and replan |
| 14 | An edge outside a cached path becomes faster | New graph version triggers a fresh exact search |
| 15 | Request times out after commit and retries with the same ID | Return the same reservation without consuming new capacity |
| 16 | Entering at 0 arrives at 20, entering at 5 arrives at 6 | With waiting permitted, choose entry 5 and arrival 6 |
| 17 | User cancels or a road changes after dispatch validation but before entry | The road-admission controller rejects the old token |

### Execution Evidence

The transcripts show the sample runs and automated test summaries.

#### Problem 1 Incident Detection

```text
$ python3 incident_detection.py < sample_events.txt
[{"incident_type": "SERVER", "window_start": 40000, "window_end": 100000, "server_ids": ["server-1"], "event_ids": ["e0", "e1", "e2", "e3", "e4"]}]

$ python3 incident_detection.py --test
Ran 18 tests in 0.002s

OK
```

#### Problem 2 Route Planning

```text
$ python3 route_planner.py --demo
Chosen roads: via-a -> via-b
Arrival: 6
Dispatch valid before closure: True
Dispatch valid after closure: False

$ python3 route_planner.py --test
Ran 15 tests in 0.025s

OK
```

## Problem 1 sample input and expected output

**Input**

```text
5
e4 server-1 100000 A 5
e2 server-1 95000 A 5
e3 server-1 98000 C 5
e0 server-1 90000 A 5
e1 server-1 93000 B 5
```

**Expected output**

```json
[{"incident_type": "SERVER", "window_start": 40000, "window_end": 100000, "server_ids": ["server-1"], "event_ids": ["e0", "e1", "e2", "e3", "e4"]}]
```

## Problem 2 sample run (`--demo`)

```text
Chosen roads: via-a -> via-b
Arrival: 6
Dispatch valid before closure: True
Dispatch valid after closure: False
```

## Verification evidence

> **About the screenshots:** each image is a capture of the actual terminal output from running the command shown, on 21 Nov 2026. The footer of each image gives the candidate ID, runtime version and run time. The full text output of the same run is in `test_output.txt`, so every value in the images can be checked.

All commands are run from inside the `section_a/` folder.

### A1 – Problem 1 sample run
Command: `python3 incident_detection.py < sample_events.txt`
Expected: `SERVER`, window `[40000, 100000]`, `server-1`, events `e0`–`e4`, identical to the expected output above.

![A1 – incident detection sample](screenshots/A1_incident_sample.png)

### A2 – Problem 1 tests (18)
Command: `python3 incident_detection.py --test`
Expected: `Ran 18 tests`, `OK`.

![A2 – incident detection tests](screenshots/A2_incident_tests.png)

### A3 – Problem 2 demo
Command: `python3 route_planner.py --demo`
Expected: `via-a -> via-b`, arrival `6`, dispatch valid `True` before the closure and `False` after it.

![A3 – route planner demo](screenshots/A3_route_demo.png)

### A4 – Problem 2 tests (15)
Command: `python3 route_planner.py --test`
Expected: 15 tests listed `... ok`, `Ran 15 tests`, `OK`.

![A4 – route planner tests](screenshots/A4_route_tests.png)
