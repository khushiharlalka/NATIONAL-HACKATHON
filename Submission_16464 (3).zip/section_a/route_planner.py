"""Run with Python 3.10+ using --demo or --test."""

import heapq
import json
import math
import sqlite3
import sys
import tempfile
import unittest
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from threading import Barrier

SCHEMA = """
CREATE TABLE IF NOT EXISTS roads (
    id TEXT PRIMARY KEY, src TEXT NOT NULL, dst TEXT NOT NULL,
    duration INTEGER NOT NULL CHECK (duration > 0),
    capacity INTEGER NOT NULL CHECK (capacity >= 0),
    available INTEGER NOT NULL CHECK (available IN (0, 1)),
    version INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
    id TEXT PRIMARY KEY, parameters TEXT NOT NULL, route TEXT NOT NULL,
    cancelled INTEGER NOT NULL DEFAULT 0 CHECK (cancelled IN (0, 1))
);
CREATE TABLE IF NOT EXISTS bookings (
    request_id TEXT NOT NULL REFERENCES requests(id),
    step INTEGER NOT NULL, road_id TEXT NOT NULL REFERENCES roads(id),
    entry INTEGER NOT NULL, exit INTEGER NOT NULL, demand INTEGER NOT NULL,
    PRIMARY KEY (request_id, step),
    CHECK (entry < exit AND demand > 0)
);
CREATE INDEX IF NOT EXISTS bookings_by_road ON bookings(road_id, entry);
"""


class RoutePlanner:
    def __init__(self, db_path):
        self.db_path = db_path
        with self.transaction(write=True) as db:
            for statement in SCHEMA.split(";"):
                if statement.strip():
                    db.execute(statement)

    @contextmanager
    def transaction(self, write=False):
        db = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        try:
            db.execute("PRAGMA foreign_keys = ON")
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def set_road(self, road_id, src, dst, base, multiplier, capacity, available=True):
        # Adjusted travel duration must be an exact number of chosen time ticks.
        duration = base * multiplier
        if not math.isfinite(duration) or duration <= 0 or int(duration) != duration:
            raise ValueError("use time ticks in which adjusted durations are positive integers")
        if not isinstance(capacity, int) or capacity < 0:
            raise ValueError("capacity must be a non-negative integer")
        with self.transaction(write=True) as db:
            old = db.execute("SELECT capacity FROM roads WHERE id = ?", (road_id,)).fetchone()
            if old and capacity < old[0]:
                peak = max((used for _, _, used in usage_segments(db, road_id)), default=0)
                if peak > capacity:
                    raise ValueError("release conflicting bookings before reducing capacity")
            db.execute(
                """INSERT INTO roads VALUES (?, ?, ?, ?, ?, ?, 1)
                   ON CONFLICT(id) DO UPDATE SET src=excluded.src, dst=excluded.dst,
                       duration=excluded.duration, capacity=excluded.capacity,
                       available=excluded.available, version=roads.version+1""",
                (road_id, src, dst, int(duration), capacity, int(available)),
            )

    def plan(self, source, destination, departure, demand):
        validate_request(departure, demand)
        with self.transaction() as db:
            return shortest_route(db, source, destination, departure, demand)

    def reserve(self, request_id, source, destination, departure, demand):
        validate_request(departure, demand)
        parameters = json.dumps([source, destination, departure, demand])
        # All instances acquire the same database write lock before reading usage.
        with self.transaction(write=True) as db:
            existing = db.execute(
                "SELECT parameters, route, cancelled FROM requests WHERE id = ?", (request_id,)
            ).fetchone()
            if existing:
                if existing[0] != parameters:
                    raise ValueError("request ID refers to different parameters")
                if existing[2]:
                    raise ValueError("request was cancelled; use a new request ID")
                return json.loads(existing[1])

            route = shortest_route(db, source, destination, departure, demand)
            if route is None:
                return None
            db.execute("INSERT INTO requests (id, parameters, route) VALUES (?, ?, ?)",
                       (request_id, parameters, json.dumps(route)))
            db.executemany(
                "INSERT INTO bookings VALUES (?, ?, ?, ?, ?, ?)",
                [(request_id, i, step["road"], step["entry"], step["exit"], demand)
                 for i, step in enumerate(route["steps"])],
            )
            return route

    def release(self, request_id):
        with self.transaction(write=True) as db:
            db.execute("DELETE FROM bookings WHERE request_id = ?", (request_id,))
            db.execute("UPDATE requests SET cancelled = 1 WHERE id = ?", (request_id,))

    def revalidate(self, request_id, now):
        with self.transaction() as db:
            row = db.execute("SELECT route FROM requests WHERE id = ? AND cancelled = 0", (request_id,)).fetchone()
            if row is None:
                return False
            steps = json.loads(row[0])["steps"]
            if steps and now > steps[0]["entry"]:
                return False
            for step in steps:
                road = db.execute(
                    "SELECT available, version FROM roads WHERE id = ?", (step["road"],)
                ).fetchone()
                if road != (1, step["version"]):
                    return False
            return True


def validate_request(departure, demand):
    if not isinstance(departure, int) or departure < 0:
        raise ValueError("departure must be a non-negative integer tick")
    if not isinstance(demand, int) or demand <= 0:
        raise ValueError("demand must be a positive integer")


def usage_segments(db, road_id):
    changes = defaultdict(int)
    for entry, exit, demand in db.execute(
        "SELECT entry, exit, demand FROM bookings WHERE road_id = ?", (road_id,)
    ):
        changes[entry] += demand
        changes[exit] -= demand
    usage = 0
    previous = None
    for time in sorted(changes):
        if previous is not None and usage:
            yield previous, time, usage
        usage += changes[time]
        previous = time


def earliest_entry(segments, ready, duration, capacity, demand):
    entry = ready
    for start, end, usage in segments:
        if start >= entry + duration:
            break
        if end > entry and usage + demand > capacity:
            entry = end
    return entry


def shortest_route(db, source, destination, departure, demand):
    graph = defaultdict(list)
    for road_id, src, dst, duration, capacity, version in db.execute(
        """SELECT id, src, dst, duration, capacity, version FROM roads
           WHERE available = 1 AND capacity >= ? ORDER BY id""", (demand,)
    ):
        graph[src].append((road_id, dst, duration, capacity, version))

    arrival = {source: departure}
    parent = {}
    queue = [(departure, source)]
    while queue:
        ready, node = heapq.heappop(queue)
        if ready != arrival[node]:
            continue
        if node == destination:
            steps = []
            while node != source:
                node, step = parent[node]
                steps.append(step)
            return {"arrival": ready, "steps": steps[::-1]}
        for road_id, dst, duration, capacity, version in graph[node]:
            entry = earliest_entry(usage_segments(db, road_id), ready, duration, capacity, demand)
            exit = entry + duration
            if exit < arrival.get(dst, math.inf):
                arrival[dst] = exit
                parent[dst] = node, {
                    "road": road_id, "entry": entry, "exit": exit, "version": version,
                }
                heapq.heappush(queue, (exit, dst))
    return None


def demo():
    with tempfile.TemporaryDirectory() as directory:
        planner = RoutePlanner(Path(directory) / "demo.sqlite")
        planner.set_road("direct", "S", "T", 4, 1, 1)
        planner.reserve("existing", "S", "T", 0, 1)
        planner.set_road("via-a", "S", "A", 3, 1, 1)
        planner.set_road("via-b", "A", "T", 3, 1, 1)
        result = planner.reserve("new", "S", "T", 0, 1)
        print("Chosen roads:", " -> ".join(step["road"] for step in result["steps"]))
        print("Arrival:", result["arrival"])
        print("Dispatch valid before closure:", planner.revalidate("new", 0))
        planner.set_road("via-b", "A", "T", 3, 1, 1, available=False)
        print("Dispatch valid after closure:", planner.revalidate("new", 0))


class RouteTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.db_path = Path(directory.name) / "routes.sqlite"
        self.planner = RoutePlanner(self.db_path)

    def road(self, name="direct", src="S", dst="T", base=4, multiplier=1,
             capacity=1, available=True):
        self.planner.set_road(name, src, dst, base, multiplier, capacity, available)

    def test_same_vertex(self):
        self.assertEqual(self.planner.plan("S", "S", 8, 1), {"arrival": 8, "steps": []})

    def test_directed_unreachable(self):
        self.road(src="T", dst="S")
        self.assertIsNone(self.planner.plan("S", "T", 0, 1))

    def test_minimum_path(self):
        self.road(base=10)
        self.road("first", "S", "A", 3)
        self.road("last", "A", "T", 4)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["arrival"], 7)

    def test_closed_road(self):
        self.road(available=False)
        self.assertIsNone(self.planner.plan("S", "T", 0, 1))

    def test_insufficient_capacity(self):
        self.road(capacity=2)
        self.assertIsNone(self.planner.plan("S", "T", 0, 3))

    def test_congestion_multiplier(self):
        self.road(base=2, multiplier=4)
        self.road("alternate", base=6)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["steps"][0]["road"], "alternate")

    def test_wait_and_touch_endpoint(self):
        self.road(base=5)
        self.planner.reserve("a", "S", "T", 0, 1)
        result = self.planner.reserve("b", "S", "T", 0, 1)
        self.assertEqual((result["steps"][0]["entry"], result["arrival"]), (5, 10))

    def test_booked_direct_can_lose_to_detour(self):
        self.road(base=10)
        self.planner.reserve("existing", "S", "T", 0, 1)
        self.road(base=4)
        self.road("first", "S", "A", 3)
        self.road("last", "A", "T", 3)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["arrival"], 6)

    def test_capacity_is_aggregate_demand(self):
        self.road(capacity=3)
        for key, demand in [("a", 1), ("b", 2)]:
            self.assertEqual(self.planner.reserve(key, "S", "T", 0, demand)["arrival"], 4)
        self.assertEqual(self.planner.reserve("c", "S", "T", 0, 1)["arrival"], 8)

    def test_concurrent_reservations(self):
        another = RoutePlanner(self.db_path)
        self.road()
        barrier = Barrier(2, timeout=5)

        def reserve(planner, key):
            barrier.wait()
            return planner.reserve(key, "S", "T", 0, 1)["arrival"]

        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(reserve, self.planner, "a")
            second = pool.submit(reserve, another, "b")
            self.assertEqual(sorted([first.result(), second.result()]), [4, 8])

    def test_dispatch_revalidation(self):
        self.road()
        self.planner.reserve("a", "S", "T", 0, 1)
        self.assertTrue(self.planner.revalidate("a", 0))
        self.assertFalse(self.planner.revalidate("a", 1))
        self.road(available=False)
        self.assertFalse(self.planner.revalidate("a", 0))

    def test_replanning_sees_unchosen_improvement(self):
        self.road()
        self.road("alternate", base=10)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["arrival"], 4)
        self.road("alternate", base=1)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["arrival"], 1)

    def test_retry_is_idempotent(self):
        self.road()
        first = self.planner.reserve("retry", "S", "T", 0, 1)
        self.assertEqual(self.planner.reserve("retry", "S", "T", 0, 1), first)
        with self.assertRaises(ValueError):
            self.planner.reserve("retry", "S", "T", 1, 1)

    def test_failed_commit_rolls_back_earlier_road(self):
        self.road("first", "S", "A", 2)
        self.road("last", "A", "T", 2)
        with self.planner.transaction(write=True) as db:
            db.execute("""CREATE TRIGGER reject_last BEFORE INSERT ON bookings
                          WHEN NEW.road_id = 'last'
                          BEGIN SELECT RAISE(ABORT, 'test failure'); END""")
        with self.assertRaises(sqlite3.IntegrityError):
            self.planner.reserve("a", "S", "T", 0, 1)
        with self.planner.transaction() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM bookings").fetchone(), (0,))
            self.assertEqual(db.execute("SELECT count(*) FROM requests").fetchone(), (0,))

    def test_release_and_capacity_reduction(self):
        self.road(capacity=2)
        self.planner.reserve("a", "S", "T", 0, 2)
        with self.assertRaises(ValueError):
            self.road(capacity=1)
        self.planner.release("a")
        self.assertFalse(self.planner.revalidate("a", 0))
        with self.assertRaises(ValueError):
            self.planner.reserve("a", "S", "T", 0, 2)
        self.road(capacity=1)
        self.assertEqual(self.planner.plan("S", "T", 0, 1)["arrival"], 4)


if __name__ == "__main__":
    if sys.argv[1:] == ["--demo"]:
        demo()
    elif sys.argv[1:] == ["--test"]:
        unittest.main(argv=[sys.argv[0]], verbosity=2)
    else:
        sys.exit("usage: python3 route_planner.py --demo or --test")
