"""Problem 1. Python 3.10+.

Run: python3 incident_detection.py < events.txt
Test: python3 incident_detection.py --test
Input lines: event_id server_id timestamp event_type severity
Output: a JSON array with zero or one incident record.
"""

import heapq
import json
import sys
import unittest
from collections import deque
from dataclasses import asdict, dataclass

LATENESS = 300_000
SERVER_DURATION = 60_000
CROSS_DURATION = 30_000


@dataclass(frozen=True, slots=True)
class Event:
    event_id: str
    server_id: str
    timestamp: int
    event_type: str
    severity: int


@dataclass(frozen=True, slots=True)
class Incident:
    incident_type: str
    window_start: int
    window_end: int
    server_ids: tuple[str, ...]
    event_ids: tuple[str, ...]


def change_count(counts, key, delta):
    count = counts.get(key, 0) + delta
    if count:
        counts[key] = count
    else:
        del counts[key]


class ServerWindow:
    def __init__(self):
        self.types = {}
        self.critical = deque()
        self.equal_pairs = 0

    def add(self, event):
        change_count(self.types, event.event_type, 1)
        if event.severity == 5:
            if self.critical and self.critical[-1].event_type == event.event_type:
                self.equal_pairs += 1
            self.critical.append(event)

    def remove(self, event):
        change_count(self.types, event.event_type, -1)
        if event.severity == 5:
            self.critical.popleft()
            if self.critical and self.critical[0].event_type == event.event_type:
                self.equal_pairs -= 1

    def qualifies(self):
        return len(self.critical) >= 5 and len(self.types) >= 3 and self.equal_pairs == 0


class WindowSweep:
    def __init__(self, duration, incident_type):
        self.duration = duration
        self.incident_type = incident_type
        self.cross = incident_type == "CROSS_SERVER"
        self.active = deque()
        self.server_counts = {}
        self.server_windows = {}
        self.changed = set()
        self.pending_end = None
        self.result = None

    def add(self, event):
        if self.result is not None or (self.cross and event.severity != 5):
            return
        end = max(self.duration, event.timestamp)
        if self.pending_end != end:
            self.advance(end)
            if self.result is not None:
                return
            self.expire(end)
            self.pending_end = end
        self.active.append(event)
        server = event.server_id
        if self.cross:
            change_count(self.server_counts, server, 1)
        else:
            if server not in self.server_windows:
                self.server_windows[server] = ServerWindow()
            self.server_windows[server].add(event)
            self.changed.add(server)

    def expire(self, end):
        start = end - self.duration
        while self.active and self.active[0].timestamp < start:
            event = self.active.popleft()
            server = event.server_id
            if self.cross:
                change_count(self.server_counts, server, -1)
            else:
                window = self.server_windows[server]
                window.remove(event)
                if not window.types:
                    del self.server_windows[server]
                self.changed.add(server)

    def advance(self, exclusive_end):
        """Evaluate complete boundaries strictly before exclusive_end."""
        if self.result is not None:
            return
        if self.pending_end is not None:
            if self.pending_end >= exclusive_end:
                return
            end = self.pending_end
            self.pending_end = None
            self.evaluate(end)
        while self.result is None and self.active:
            expiration = self.active[0].timestamp + self.duration + 1
            if expiration >= exclusive_end:
                break
            self.expire(expiration)
            self.evaluate(expiration)

    def evaluate(self, end):
        if self.cross:
            if len(self.server_counts) >= 4:
                self.emit(end, tuple(sorted(self.server_counts)), self.active)
            return

        winner = min(
            (server for server in self.changed
             if server in self.server_windows and self.server_windows[server].qualifies()),
            default=None,
        )
        self.changed.clear()
        if winner is None:
            return

        critical = self.server_windows[winner].critical
        seen_types = {event.event_type for event in critical}
        supporting_ids = set()
        if len(seen_types) < 3:
            for event in self.active:
                if event.server_id == winner and event.event_type not in seen_types:
                    supporting_ids.add(event.event_id)
                    seen_types.add(event.event_type)
                    if len(seen_types) == 3:
                        break
        if supporting_ids:
            contributing = (
                event for event in self.active
                if event.server_id == winner
                and (event.severity == 5 or event.event_id in supporting_ids)
            )
        else:
            contributing = critical
        self.emit(end, (winner,), contributing)

    def emit(self, end, servers, contributing):
        self.result = Incident(
            self.incident_type,
            end - self.duration,
            end,
            servers,
            tuple(event.event_id for event in contributing),
        )
        self.active.clear()
        self.server_counts.clear()
        self.server_windows.clear()
        self.changed.clear()


def detect_incidents(deliveries):
    """Find the first window overall. Behind-watermark deliveries are ignored."""
    server_sweep = WindowSweep(SERVER_DURATION, "SERVER")
    cross_sweep = WindowSweep(CROSS_DURATION, "CROSS_SERVER")
    sweeps = (server_sweep, cross_sweep)
    heap = []
    buffered_ids = set()
    watermark = -LATENESS

    def release_before(limit):
        while heap and heap[0][0] < limit:
            _, event_id, event = heapq.heappop(heap)
            buffered_ids.remove(event_id)
            for sweep in sweeps:
                sweep.add(event)
        for sweep in sweeps:
            sweep.advance(limit)

    for event in deliveries:
        if event.timestamp < watermark or event.event_id in buffered_ids:
            continue
        heapq.heappush(heap, (event.timestamp, event.event_id, event))
        buffered_ids.add(event.event_id)
        new_watermark = event.timestamp - LATENESS
        if new_watermark > watermark:
            watermark = new_watermark
            release_before(watermark)

    release_before(float("inf"))
    candidates = [sweep.result for sweep in sweeps if sweep.result is not None]
    if not candidates:
        return []
    return [min(candidates, key=lambda incident: (
        incident.window_start,
        incident.incident_type != "SERVER",
        incident.server_ids,
    ))]


def read_events(stream, count):
    for _ in range(count):
        event_id, server_id, timestamp, event_type, severity = stream.readline().split()
        yield Event(event_id, server_id, int(timestamp), event_type, int(severity))


class IncidentTests(unittest.TestCase):
    @staticmethod
    def server(types="ABACA", timestamps=None, server_id="s", prefix="e"):
        if timestamps is None:
            timestamps = range(len(types))
        return [
            Event(f"{prefix}{index}", server_id, timestamp, kind, 5)
            for index, (kind, timestamp) in enumerate(zip(types, timestamps))
        ]

    @staticmethod
    def cross(timestamps):
        return [
            Event(f"c{index}", f"s{index}", timestamp, "A", 5)
            for index, timestamp in enumerate(timestamps)
        ]

    def test_empty(self):
        self.assertEqual(detect_incidents([]), [])

    def test_four_critical_events(self):
        self.assertEqual(detect_incidents(self.server("ABAC")), [])

    def test_five_qualifying_events(self):
        self.assertEqual(detect_incidents(self.server()), [
            Incident("SERVER", 0, 60_000, ("s",), ("e0", "e1", "e2", "e3", "e4")),
        ])

    def test_two_event_types(self):
        self.assertEqual(detect_incidents(self.server("ABABA")), [])

    def test_equal_adjacent_critical_types(self):
        self.assertEqual(detect_incidents(self.server("AABCA")), [])

    def test_reverse_delivery(self):
        events = self.server(timestamps=[90_000, 93_000, 95_000, 98_000, 100_000])
        self.assertEqual(detect_incidents(reversed(events)), detect_incidents(events))
        self.assertEqual(detect_incidents(events)[0].window_start, 40_000)

    def test_duplicates_cannot_turn_four_into_five(self):
        events = self.server("ABAC")
        self.assertEqual(detect_incidents(events + [events[0]]), [])

    def test_duplicates_before_and_after_buffer_release(self):
        events = self.server()
        later = Event("later", "z", 400_000, "X", 1)
        self.assertEqual(
            detect_incidents(events + [events[4], later, events[2]]),
            detect_incidents(events),
        )

    def test_cross_inclusive_endpoint(self):
        result, = detect_incidents(self.cross([0, 10_000, 20_000, 30_000]))
        self.assertEqual(result.incident_type, "CROSS_SERVER")
        self.assertEqual((result.window_start, result.window_end), (0, 30_000))
        self.assertEqual(result.server_ids, ("s0", "s1", "s2", "s3"))

    def test_cross_one_millisecond_outside(self):
        self.assertEqual(detect_incidents(self.cross([0, 10_000, 20_000, 30_001])), [])

    def test_lateness_boundary_included(self):
        events = self.server(timestamps=[100, 101, 102, 103, 104])
        later = Event("later", "z", 300_100, "X", 1)
        self.assertEqual(detect_incidents([later, *events]), detect_incidents(events))

    def test_one_millisecond_behind_watermark(self):
        events = self.server(timestamps=[99, 101, 102, 103, 104])
        later = Event("later", "z", 300_100, "X", 1)
        self.assertEqual(detect_incidents([later, *events]), [])

    def test_validity_can_begin_on_expiration(self):
        events = self.server("AABACA", [0, 1, 2, 3, 4, 60_000])
        result, = detect_incidents(events)
        self.assertEqual((result.window_start, result.window_end), (1, 60_001))
        self.assertEqual(result.event_ids, ("e1", "e2", "e3", "e4", "e5"))

    def test_equal_timestamps_use_event_id_and_complete_the_batch(self):
        good = self.server("ABACA", [20] * 5)
        bad = self.server("AABCA", [20] * 5)
        self.assertEqual(len(detect_incidents(reversed(good))), 1)
        self.assertEqual(detect_incidents(reversed(bad)), [])
        extra = Event("e5", "s", 20, "A", 5)
        self.assertEqual(detect_incidents([*good, extra]), [])

    def test_noncritical_can_supply_a_distinct_type(self):
        events = self.server("ABABA") + [Event("support", "s", 8, "C", 3)]
        result, = detect_incidents(events)
        self.assertEqual(result.event_ids, ("e0", "e1", "e2", "e3", "e4", "support"))

    def test_choose_by_start_even_when_cross_window_ends_first(self):
        events = self.cross([31_000, 31_000, 31_000, 31_000]) + self.server(
            timestamps=[40_000, 41_000, 42_000, 43_000, 60_000], server_id="z",
        )
        self.assertEqual(detect_incidents(events)[0].incident_type, "SERVER")

    def test_lexicographic_server_tie(self):
        events = self.server(server_id="z") + self.server(server_id="a", prefix="a")
        self.assertEqual(detect_incidents(events)[0].server_ids, ("a",))

    def test_incident_type_tie(self):
        events = self.cross([30_000] * 4) + self.server(
            timestamps=[55_000, 56_000, 57_000, 58_000, 60_000], server_id="z",
        )
        self.assertEqual(detect_incidents(events)[0].incident_type, "SERVER")


if __name__ == "__main__":
    if sys.argv[1:] == ["--test"]:
        unittest.main(argv=[sys.argv[0]])
    else:
        first_line = sys.stdin.readline()
        count = int(first_line) if first_line.strip() else 0
        print(json.dumps([asdict(incident) for incident in detect_incidents(
            read_events(sys.stdin, count)
        )]))
