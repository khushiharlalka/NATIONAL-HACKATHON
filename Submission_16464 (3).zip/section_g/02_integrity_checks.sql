-- Section G §8 - integrity checks for the incident window. Candidate 16464.
-- Run:  psql -d incident_demo -f 02_integrity_checks.sql
-- A clean database returns 0 rows for 8.1-8.4 and 8.6.

\echo '==== 8.1 Teams with more than one active registration'
SELECT team_id, COUNT(*) AS active_regs, array_agg(id ORDER BY created_at) AS reg_ids
FROM registrations
WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED')
GROUP BY team_id HAVING COUNT(*) > 1;

\echo '==== 8.2 Capacity counter drift / oversold tracks'
SELECT t.id, t.capacity, t.reserved,
       COUNT(r.id) FILTER (WHERE r.seat_held)                AS actual_held,
       t.reserved - COUNT(r.id) FILTER (WHERE r.seat_held)   AS drift,
       COUNT(r.id) FILTER (WHERE r.seat_held) > t.capacity   AS oversold
FROM tracks t LEFT JOIN registrations r ON r.track_id = t.id
GROUP BY t.id, t.capacity, t.reserved
HAVING t.reserved <> COUNT(r.id) FILTER (WHERE r.seat_held)
    OR COUNT(r.id) FILTER (WHERE r.seat_held) > t.capacity
ORDER BY t.id;

\echo '==== 8.3 Duplicate charges (more than one unrefunded success per team)'
SELECT team_id, COUNT(*) AS captured, SUM(amount) AS total, array_agg(id ORDER BY created_at) AS payment_ids
FROM payments
WHERE status = 'succeeded' AND refunded_at IS NULL AND created_at >= '2026-11-21 11:15+05:30'
GROUP BY team_id HAVING COUNT(*) > 1;

\echo '==== 8.4 Money without seat / seat without money'
SELECT r.id, r.team_id, r.state, p.id AS payment_id, p.status AS payment_status,
       CASE WHEN r.state = 'CONFIRMED' THEN 'CONFIRMED_WITHOUT_PAYMENT'
            ELSE 'CHARGED_NOT_REFUNDED' END AS problem
FROM registrations r LEFT JOIN payments p ON p.registration_id = r.id
WHERE (r.state = 'CONFIRMED' AND p.status IS DISTINCT FROM 'succeeded')
   OR (r.state IN ('FAILED','CANCELLED') AND p.status = 'succeeded' AND p.refunded_at IS NULL)
ORDER BY r.id;

\echo '==== 8.5 Stuck in-flight registrations (> 15 min)'
SELECT state, COUNT(*) AS n, MIN(updated_at) AS oldest, array_agg(id) AS reg_ids
FROM registrations
WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN') AND updated_at < now() - interval '15 minutes'
GROUP BY state;

\echo '==== 8.6 Duplicate notifications'
SELECT dedup_key, COUNT(*) AS sends
FROM notification_deliveries
WHERE sent_at >= '2026-11-21 11:15+05:30'
GROUP BY dedup_key HAVING COUNT(*) > 1;

\echo '==== 8.7 Registrations decided by the new validation rules (re-check offline)'
SELECT validation_result, COUNT(*) AS n, array_agg(id ORDER BY id) AS reg_ids
FROM registrations
WHERE created_at >= '2026-11-21 11:20+05:30' AND validation_version = 'v_new'
GROUP BY validation_result ORDER BY validation_result;
