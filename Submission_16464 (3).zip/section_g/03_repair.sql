-- Section G §8 repair rules - one audited transaction. Candidate 16464.
-- Run:  psql -v ON_ERROR_STOP=1 -d incident_demo -f 03_repair.sql
BEGIN;
LOCK TABLE tracks, registrations, payments IN SHARE ROW EXCLUSIVE MODE;

-- Rule 1: duplicate active registration -> keep earliest CONFIRMED, cancel the rest + refund
WITH ranked AS (
  SELECT id, team_id, row_number() OVER (PARTITION BY team_id ORDER BY created_at) AS rn
  FROM registrations
  WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED')
), dup AS (
  UPDATE registrations r SET state = 'CANCELLED', seat_held = false, updated_at = now()
  FROM ranked WHERE ranked.id = r.id AND ranked.rn > 1
  RETURNING r.id
)
INSERT INTO repair_audit(incident, entity, entity_id, action, before_val, after_val, actor)
SELECT 'INC-REG-001', 'registration', id, 'CANCEL_DUPLICATE', 'CONFIRMED', 'CANCELLED', 'oncall:16464' FROM dup;

-- Rule 2: money taken for a registration that is not confirmed -> refund
--         (in production: provider.refund(idempotency_key = 'refund_' || payment_id), then mark)
WITH to_refund AS (
  UPDATE payments p SET refunded_at = now()
  FROM registrations r
  WHERE p.registration_id = r.id AND r.state IN ('FAILED','CANCELLED')
    AND p.status = 'succeeded' AND p.refunded_at IS NULL
  RETURNING p.id
)
INSERT INTO repair_audit(incident, entity, entity_id, action, before_val, after_val, actor)
SELECT 'INC-REG-001', 'payment', id, 'REFUND', 'succeeded', 'succeeded+refunded', 'oncall:16464' FROM to_refund;

-- Rule 3: CONFIRMED without a payment -> do not guess; send to the reconciler, hold the seat
WITH unk AS (
  UPDATE registrations r SET state = 'PAYMENT_UNKNOWN', seat_held = true, updated_at = now()
  WHERE r.state = 'CONFIRMED'
    AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.registration_id = r.id AND p.status = 'succeeded')
  RETURNING r.id
)
INSERT INTO repair_audit(incident, entity, entity_id, action, before_val, after_val, actor)
SELECT 'INC-REG-001', 'registration', id, 'SEND_TO_RECONCILER', 'CONFIRMED', 'PAYMENT_UNKNOWN', 'oncall:16464' FROM unk;

-- Rule 4: counter drift -> set counter to the real number of held seats
WITH actual AS (
  SELECT t.id, t.reserved AS before, COUNT(r.id) FILTER (WHERE r.seat_held) AS held
  FROM tracks t LEFT JOIN registrations r ON r.track_id = t.id GROUP BY t.id, t.reserved
), fixed AS (
  UPDATE tracks t SET reserved = a.held FROM actual a
  WHERE a.id = t.id AND t.reserved <> a.held
  RETURNING t.id, a.before, a.held
)
INSERT INTO repair_audit(incident, entity, entity_id, action, before_val, after_val, actor)
SELECT 'INC-REG-001', 'track', id, 'RESET_COUNTER', before::text, held::text, 'oncall:16464' FROM fixed;

-- Rule 5 (guard): still oversold after repairs? stop - this is a business decision, not a script.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM tracks WHERE reserved > capacity) THEN
    RAISE EXCEPTION 'Track still oversold after repair - escalate to business owner';
  END IF;
END $$;

-- Prevention (P9): make these states impossible from now on
CREATE UNIQUE INDEX IF NOT EXISTS one_active_registration_per_team
  ON registrations(team_id)
  WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED');
ALTER TABLE tracks DROP CONSTRAINT IF EXISTS reserved_within_capacity;
ALTER TABLE tracks ADD CONSTRAINT reserved_within_capacity CHECK (reserved <= capacity);

COMMIT;

\echo '==== Repair audit trail'
SELECT entity, entity_id, action, before_val, after_val, actor FROM repair_audit ORDER BY id;
