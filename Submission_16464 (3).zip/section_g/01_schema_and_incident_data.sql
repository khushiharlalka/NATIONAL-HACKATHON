-- Section G - Candidate 16464
-- Synthetic registration database containing the kinds of damage the incident could cause.
-- Run:  psql -v ON_ERROR_STOP=1 -d incident_demo -f 01_schema_and_incident_data.sql

DROP TABLE IF EXISTS repair_audit, notification_deliveries, payments, registrations, tracks, teams CASCADE;

CREATE TABLE teams (
  id          text PRIMARY KEY,
  email       text NOT NULL
);

CREATE TABLE tracks (
  id          text PRIMARY KEY,
  capacity    int  NOT NULL CHECK (capacity >= 0),
  reserved    int  NOT NULL CHECK (reserved >= 0)        -- counter (drift is what we look for)
);

CREATE TABLE registrations (
  id                  text PRIMARY KEY,
  team_id             text NOT NULL REFERENCES teams(id),
  track_id            text NOT NULL REFERENCES tracks(id),
  state               text NOT NULL,
  seat_held           boolean NOT NULL,
  validation_version  text NOT NULL,
  validation_result   text NOT NULL,
  created_at          timestamptz NOT NULL,
  updated_at          timestamptz NOT NULL
);

CREATE TABLE payments (
  id               text PRIMARY KEY,
  registration_id  text REFERENCES registrations(id),
  team_id          text NOT NULL REFERENCES teams(id),
  amount           int  NOT NULL,
  status           text NOT NULL,
  refunded_at      timestamptz,
  created_at       timestamptz NOT NULL
);

CREATE TABLE notification_deliveries (
  id          bigserial PRIMARY KEY,
  dedup_key   text NOT NULL,
  sent_at     timestamptz NOT NULL
);

CREATE TABLE repair_audit (
  id          bigserial PRIMARY KEY,
  incident    text NOT NULL,
  entity      text NOT NULL,
  entity_id   text NOT NULL,
  action      text NOT NULL,
  before_val  text,
  after_val   text,
  actor       text NOT NULL,
  at          timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- data
INSERT INTO teams VALUES
 ('TEAM01','t01@x.in'),('TEAM02','t02@x.in'),('TEAM03','t03@x.in'),('TEAM04','t04@x.in'),
 ('TEAM05','t05@x.in'),('TEAM06','t06@x.in'),('TEAM07','t07@x.in'),('TEAM08','t08@x.in');

-- TRK-AI: capacity 3 but 4 seats held (oversold) and the counter says 3 (drift)
-- TRK-WEB: capacity 5, 1 seat held, counter says 3 (seat leak from a crash)
INSERT INTO tracks VALUES ('TRK-AI', 3, 3), ('TRK-WEB', 5, 3);

INSERT INTO registrations VALUES
 -- before the incident: clean
 ('R01','TEAM01','TRK-AI','CONFIRMED',true ,'v_old','accepted','2026-11-21 10:50+05:30','2026-11-21 10:50+05:30'),
 -- during the incident
 ('R02','TEAM02','TRK-AI','CONFIRMED',true ,'v_new','accepted','2026-11-21 11:22+05:30','2026-11-21 11:22+05:30'),
 ('R03','TEAM02','TRK-AI','CONFIRMED',true ,'v_new','accepted','2026-11-21 11:24+05:30','2026-11-21 11:24+05:30'), -- duplicate (retry storm)
 ('R04','TEAM03','TRK-AI','CONFIRMED',true ,'v_new','accepted','2026-11-21 11:26+05:30','2026-11-21 11:26+05:30'), -- 4th seat on cap 3
 ('R05','TEAM04','TRK-WEB','CONFIRMED',true ,'v_new','accepted','2026-11-21 11:27+05:30','2026-11-21 11:27+05:30'),
 ('R06','TEAM05','TRK-WEB','FAILED',  false,'v_new','accepted','2026-11-21 11:28+05:30','2026-11-21 11:29+05:30'), -- failed but charged
 ('R07','TEAM06','TRK-WEB','PAYMENT_PENDING',false,'v_new','accepted','2026-11-21 11:31+05:30','2026-11-21 11:31+05:30'), -- stuck
 ('R08','TEAM07','TRK-WEB','FAILED',  false,'v_new','rejected','2026-11-21 11:33+05:30','2026-11-21 11:33+05:30'), -- new rule rejected
 ('R09','TEAM08','TRK-WEB','CONFIRMED',false,'v_new','accepted','2026-11-21 11:34+05:30','2026-11-21 11:34+05:30'); -- confirmed, no payment, no seat flag

INSERT INTO payments VALUES
 ('P01','R01','TEAM01',1000,'succeeded',NULL,'2026-11-21 10:50+05:30'),
 ('P02','R02','TEAM02',1000,'succeeded',NULL,'2026-11-21 11:22+05:30'),
 ('P03','R03','TEAM02',1000,'succeeded',NULL,'2026-11-21 11:24+05:30'), -- double charge
 ('P04','R04','TEAM03',1000,'succeeded',NULL,'2026-11-21 11:26+05:30'),
 ('P05','R05','TEAM04',1000,'succeeded',NULL,'2026-11-21 11:27+05:30'),
 ('P06','R06','TEAM05',1000,'succeeded',NULL,'2026-11-21 11:28+05:30'); -- charged but FAILED, not refunded
 -- R09 has no payment

INSERT INTO notification_deliveries(dedup_key, sent_at) VALUES
 ('email:confirmed:R01','2026-11-21 10:51+05:30'),
 ('email:confirmed:R02','2026-11-21 11:23+05:30'),
 ('email:confirmed:R02','2026-11-21 11:41+05:30'),   -- duplicate send
 ('email:confirmed:R02','2026-11-21 11:52+05:30'),   -- duplicate send
 ('email:confirmed:R05','2026-11-21 11:28+05:30');

SELECT 'schema + incident data loaded' AS status,
       (SELECT count(*) FROM registrations) AS registrations,
       (SELECT count(*) FROM payments)      AS payments;
