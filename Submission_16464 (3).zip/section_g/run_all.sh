#!/usr/bin/env bash
# Section G - run every SQL file in order. Candidate 16464.
# Usage: ./run_all.sh            (uses local PostgreSQL; set PGUSER/PGHOST/PGPASSWORD if needed)
set -euo pipefail
cd "$(dirname "$0")"
DB=incident_demo
export PGTZ=Asia/Kolkata
dropdb --if-exists "$DB" && createdb "$DB"
PSQL="psql -X -v ON_ERROR_STOP=1 -d $DB"

echo; echo "######## STEP 1 - load schema + incident data";     $PSQL -f 01_schema_and_incident_data.sql
echo; echo "######## STEP 2 - integrity checks (BEFORE repair)"; $PSQL -f 02_integrity_checks.sql
echo; echo "######## STEP 3 - audited repair";                  $PSQL -f 03_repair.sql
echo; echo "######## STEP 4 - integrity checks (AFTER repair)";  $PSQL -f 02_integrity_checks.sql
echo; echo "######## STEP 5 - live diagnostics";                $PSQL -f 04_live_diagnostics.sql
echo; echo "######## DONE"
