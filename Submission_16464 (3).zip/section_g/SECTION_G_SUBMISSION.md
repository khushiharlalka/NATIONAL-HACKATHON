# Candidate Submission – Section G: Production Incident Investigation

**Candidate ID:** 16464
**Chosen programming language(s):** SQL (PostgreSQL), shell / PromQL for diagnostics
**Submission repository/path:** `section_g/` → `SECTION_G_SUBMISSION.md`, `01_schema_and_incident_data.sql`, `02_integrity_checks.sql`, `03_repair.sql`, `04_live_diagnostics.sql`, `run_all.sh`, `screenshots/`
**Setup / run command:** PostgreSQL 13+ (tested on 16.15) → `./run_all.sh` (or run the four `.sql` files in order with `psql -d incident_demo -f <file>`)

---

## Incident Report – INC-REG-001: Registration platform degradation after release

| Field | Value |
|---|---|
| Severity | **SEV-1** (24% errors on a revenue path; capacity and payment integrity at risk) |
| Status at time of writing | Investigating → Containing |
| Incident commander | On-call engineer (me) until a dedicated IC is assigned |
| Roles to assign at once | IC, Ops lead (hands on keyboard), Comms lead, DB SME, Scribe |
| Detected | 11:30 by monitoring alert |
| Suspected trigger | Release at 11:20 (5 changes in a single deployment) |

**Facts vs assumptions.** The numbers in §1 come from the alert. Anything marked *(to confirm)* is an assumption I still have to check against data. I do not name a root cause in this report until the evidence in §4 supports it.

---

## 1. Symptoms (facts from monitoring)

| Metric | Normal | Current | Multiple | First reading |
|---|---:|---:|---:|---|
| API P95 latency | 180 ms | 8,500 ms | 47× | Requests are queueing, not just running slowly |
| Error rate | 0.5% | 24% | 48× | Probably timeouts and 5xx from waiting on the DB or Redis |
| DB CPU | 45% | 99% | 2.2× | DB is saturated, so everything downstream of it waits |
| Redis latency | 5 ms | 900 ms | 180× | Redis is overloaded or blocked; the cache is now making things slower |
| Queue depth | 2,000 | 450,000 | 225× | Producers are outrunning consumers, or consumers are failing |
| Active connections | 5,000 | 85,000 | 17× | A connection storm from retries, pool misconfiguration or more workers |

Every metric moved together. That points to **several causes feeding back into each other**, not one isolated fault.

---

## 2. Timeline

| Time (IST) | Event | Source |
|---|---|---|
| 11:20 | Release deployed: new DB index, API response caching on, worker concurrency 10 → 100, registration validation changed, notifications released | CD pipeline log |
| 11:20–11:30 | Degradation starts *(exact start time per metric to confirm from dashboards)* | Metrics |
| 11:30 | Alert fires: P95 8.5 s, errors 24%, DB CPU 99% | Monitoring |
| 11:32 | SEV-1 declared, incident channel opened, **deploy freeze** | IC |
| 11:35 | Evidence snapshot taken (see §4.1) before any changes | Ops |
| 11:38 | Containment step 1: load shedding and retry caps (§5) | Ops |
| 11:40 | Containment step 2: worker concurrency back to 10, notifications feature flag off | Ops |
| 11:45 | Containment step 3: response caching flag off for registration and capacity endpoints | Ops |
| 11:55 | Rollback decision point (§6) | IC |
| +recovery | Controlled queue drain, integrity checks (§7–§8), registration re-opened | Ops, DB SME |
| +48 h | Blameless post-incident review | Engineering manager |

*Times after 11:30 are the planned sequence. The Scribe records the actual times as each action is taken.*

---

## 3. First five investigation steps (Task 1)

| # | Step | Why it comes in this position |
|---|---|---|
| 1 | **Stabilise and preserve:** declare SEV-1, freeze deploys, and snapshot evidence (`pg_stat_activity`, `pg_stat_statements`, `pg_locks`, Redis `SLOWLOG` and `INFO`, queue stats, pod and pool metrics) | Containment will erase the evidence (killed queries, restarted pods). Freezing deploys stops someone else changing things while we look. It takes 3 minutes. |
| 2 | **Break down the change:** for each of the 5 changes, check whether it can be switched off by flag or config without a redeploy, and when exactly it went live. Overlay those times on the onset of each metric | This tells us which levers are cheap and reversible. If the onset is staggered, it shows which change caused which symptom. |
| 3 | **Find what is saturating the DB:** top queries by total time in `pg_stat_statements`; the `application_name` / client of active sessions (API vs workers vs migration); locks and waits; whether the index build is still running | DB CPU at 99% is the common bottleneck. Every other symptom (latency, Redis fallbacks, retries, connections) can follow from it. |
| 4 | **Split the traffic sources:** request rate and retry rate at the edge vs normal; worker throughput and failure rate; connection count per service and per pod; Redis ops/s and hit ratio | This separates *more load coming in* (retries, stampede, 10× workers) from *each unit of work costing more* (slow query, validation change). |
| 5 | **Look at consumer health and the integrity risk:** dead-letter and redelivery counts, consumer error logs, poison messages; and whether capacity or registrations are being written during the errors | Decides whether the queue is a symptom (backpressure from the DB) or a cause (crash-looping consumers retrying). It also tells us how big the data-integrity check in §8 needs to be. |

Steps 1–2 take about 5 minutes and allow safe containment to start straight away. Steps 3–5 run alongside containment.

---

## 4. Hypotheses and evidence (Tasks 2 and 3)

### 4.1 Evidence captured before mitigation

| Category | Data required |
|---|---|
| **Deployment** | Release manifest and diff; flag and config change log with timestamps; migration log (was the index created `CONCURRENTLY`, how long did it take, is it still building, is it valid); canary vs fleet versions; worker deployment spec (replicas × concurrency × pool size) |
| **Metrics** | RPS by endpoint and status code; client retry rate; DB CPU, IOPS, lock waits, active vs idle-in-transaction sessions; connection pool in-use / waiting / timeouts per service; Redis latency, ops/s, hit ratio, evictions, memory, CPU, client count; queue publish rate vs consume rate, redeliveries, DLQ size, consumer lag |
| **Logs** | API 5xx and timeout errors broken down by type; pool-acquire timeouts; Redis timeout errors; worker exceptions and stack traces; notification-provider errors; validation rejects and errors |
| **Traces** | Slow-request traces, comparing time spent in DB, Redis, waiting for a connection, and external calls; cache miss → DB fan-out; retry chains (one request ID repeated across attempts) |
| **Query plans** | `EXPLAIN (ANALYZE, BUFFERS)` for the top 10 queries by total time; plans before and after the new index (plan regression?); queries added by the new validation; any query without a `LIMIT` |
| **DB internals** | `pg_stat_activity` (state, wait_event, query, application_name); `pg_locks` blocking tree; `pg_stat_progress_create_index`; autovacuum activity |
| **Redis** | `SLOWLOG GET 50`, `INFO commandstats`, `--bigkeys`; whether `KEYS`, large `MGET` or big values were introduced; TTL distribution of the new cache keys |

### 4.2 Hypotheses (none confirmed yet; several may be true at once)

| ID | Hypothesis | Linked change | Explains | Evidence that would confirm or rule it out |
|---|---|---|---|---|
| H1 | **Worker-induced DB overload:** 10× concurrency multiplies DB queries and connections; notification and backlog jobs compete with API traffic | Concurrency 10 → 100, notifications | DB CPU, connections, latency | Most DB sessions have `application_name = worker`; DB CPU drops quickly when concurrency goes back to 10 |
| H2 | **Connection-pool exhaustion / connection storm:** worker pods × 100 × pool size, plus API retries, exceed what the DB and proxy can serve | Concurrency, retries | 85k connections, pool timeouts, 5xx | Pool wait-time and timeout metrics; connections grouped by service; many idle connections alongside waiting threads |
| H3 | **Cache stampede / Redis overload:** caching added with a shared TTL, no request coalescing, very large or hot keys; on expiry or miss, thousands of requests hit the DB together | Response caching | Redis 900 ms, DB CPU spikes in waves, latency | Low hit ratio; periodic DB spikes matching TTL; Redis CPU at 100% or big keys in SLOWLOG; DB load drops with the caching flag off |
| H4 | **Slow or unbounded query:** the new validation runs an expensive query (e.g. `COUNT(*)` or a duplicate check without an index or `LIMIT`), or the new index changed the planner's choice for the worse | Validation change, index | DB CPU, latency | A query fingerprint dominating `pg_stat_statements`; sequential scans in `EXPLAIN`; plan differs from the pre-deploy baseline |
| H5 | **Index migration side effects:** a non-concurrent build locked writes; or a concurrent build is consuming CPU and I/O; or each write now pays extra index-maintenance cost | Index | DB CPU, lock waits, write latency | `pg_stat_progress_create_index`; `Lock` wait events on the registration table; whether the index is marked invalid |
| H6 | **Queue consumer failure:** notification consumers crash on a new message format or provider error, then nack and requeue, so the queue grows and redeliveries loop | Notifications | Queue 450k, worker errors | Consume rate ≈ 0 or redeliveries ≫ new publishes; same exception repeating in logs; growth even while the DB is healthy |
| H7 | **Retry amplification:** client, API, SDK and worker retries without backoff or jitter multiply load once latency passes timeouts | All of the above (amplifier) | Connections 17×, errors, queue | Edge RPS ≫ unique request IDs; the same idempotency key or request ID seen many times; load falls immediately when retry caps are applied |
| H8 | **Producer-side growth:** notifications publish several messages per registration, or the validation change re-enqueues jobs | Notifications, validation | Queue 450k | Publish rate ≫ baseline while the consume rate is normal |

**Most likely interaction (to verify):** H1 + H4/H5 saturate the DB, which triggers H2 and H7. H3 adds DB load in waves, and H6/H8 fill the queue, which keeps the workers busy. Breaking the feedback loop (H1, H7) comes first, even before the exact root cause is known.

### 4.3 Telling the causes apart (required diagnostic reasoning)

| Condition | Key signature | Distinguishing test | Not this condition if… |
|---|---|---|---|
| **DB CPU saturation** | CPU ~100%; many sessions **active** with CPU wait events; slow even for simple queries | `pg_stat_activity` shows active, not waiting; adding read replicas or removing load reduces latency proportionally | Sessions are mostly `idle` or `ClientRead`, or waiting on locks |
| **Connection-pool exhaustion** | App threads waiting for a connection; pool-acquire timeouts; DB may not be CPU-bound | High pool wait time while DB query time is normal; connections ≈ max_connections or the proxy limit; trace time is "waiting for connection" not "query" | Pool wait ≈ 0 and time is spent inside queries |
| **Cache stampede** | Redis hit ratio collapses periodically; DB spikes line up with TTL expiry; many identical queries at the same moment | Spikes repeat with the same period as the TTL; the same cache key is missed concurrently by many requests; flag off makes the spikes disappear | Hit ratio is steady and DB load is flat rather than spiky |
| **Slow / unbounded query** | One or a few query fingerprints dominate total time; high rows or buffers per call | `pg_stat_statements` ranking; `EXPLAIN ANALYZE` shows seq scans or huge sorts; calls/s near normal but time per call far higher | Load is spread evenly across many normal queries |
| **Worker-induced DB overload** | DB sessions mostly come from workers; API queries are victims (fast in a plan, slow in practice) | Group sessions and query time by `application_name`; reducing worker concurrency cuts DB CPU | Workers are idle or below baseline |
| **Queue consumer failure** | Consume rate drops or redeliveries soar; repeated exceptions; queue grows even when the DB is fine | Redelivery count, DLQ growth, consumer restarts / crash loops, one message ID processed again and again | Consumers ack at a normal rate and only the publish rate is high (H8) |
| **Retry amplification** | Requests per unique user operation ≫ 1; load grows *after* errors start; synchronised bursts | Count of attempts per request or idempotency key; edge RPS vs unique sessions; capping retries cuts load immediately | One attempt per operation |

---

## 5. Containment plan (Task 4)

Order: **cheapest and most reversible first**. Each step: apply, watch for 3–5 minutes, record the effect in the timeline. That record *is* evidence for the hypotheses.

| # | Action | Targets | Reversible | Integrity note |
|---|---|---|---|---|
| C1 | Deploy freeze; snapshot evidence (§4.1) | – | Yes | Keeps the forensic trail |
| C2 | **Load shedding:** rate-limit registration API at the gateway; return `503 + Retry-After` instead of letting requests queue; turn on circuit breakers to the DB and Redis | H7, H2 | Yes | Fails fast **before** any write; no half-finished registrations |
| C3 | **Cap retries:** clients and SDK max 1 retry with exponential backoff and jitter; workers stop requeuing immediately (delayed requeue with backoff) | H7, H6 | Yes | Idempotency keys stop duplicates from the retries that remain |
| C4 | **Worker concurrency 100 → 10** by config (no redeploy); scale worker pods down if needed | H1, H2 | Yes | Workers keep acking honestly; nothing is dropped |
| C5 | **Notifications flag off** at the producer; **pause** the notification consumer (do not purge the queue) | H6, H8, H1 | Yes | Messages are kept for later replay; registrations are not affected |
| C6 | **Response caching flag off** for registration, capacity and seat-availability endpoints at minimum; if Redis is still slow, stop the offending command or big key | H3 | Yes | Stops stale capacity being shown or acted on |
| C7 | **Cancel the runaway queries** identified in step 3 (`pg_cancel_backend`, not `pg_terminate_backend` first); set `statement_timeout` for the app role (e.g. 5 s) | H4 | Yes | Cancelled transactions roll back atomically |
| C8 | Index: if a non-concurrent build is holding locks, **cancel it**; if `CONCURRENTLY` is running, let it finish unless CPU is critical, then cancel and drop the invalid index | H5 | Yes | DDL is transactional; cancelling leaves the data intact |
| C9 | If capacity integrity is in doubt: **pause new registrations** (maintenance banner "Registrations temporarily paused") while reads stay up | Integrity | Yes | Prevents overselling while counts are checked |

**Not done during containment:** purging queues, restarting the DB, raising `max_connections` (it makes CPU saturation worse), or manually editing capacity rows.

**Success criteria for containment:** error rate < 2%, P95 < 1 s, DB CPU < 70%, connections < 10k, queue depth no longer growing. All of these hold for 15 minutes.

---

## 6. Rollback decision (Task 5)

**Default stance:** this release bundled 5 changes and the impact is SEV-1. If containment by flag and config does not meet the success criteria **by 11:55 (about 25 minutes after the alert)**, roll back the application. Diagnosing comes after the platform is healthy.

| Evidence | Decision |
|---|---|
| Onset of metrics matches the 11:20 deploy (±2 min) and nothing else changed (traffic, infra, provider status) | Release is the likely trigger → rollback is justified |
| Canary or old-version pods (if any) are healthy while new-version pods fail | Strong case → roll back the application now |
| C4–C6 bring metrics back to the success criteria | **No full rollback needed**; keep the flags off and fix forward |
| Metrics still degraded after C2–C8 *and* the dominant query or error comes from new code (validation) | **Roll back the application** to the previous version |
| Traffic or an external dependency explains the load (e.g. a marketing spike, Redis host failure) | Rollback won't help → scale or fail over instead |

**How to roll back safely:**
- **App code:** roll back to the previous image. This is safe because the schema change (an added index) is backward-compatible.
- **Index:** don't drop it while it's healthy. Drop it (`DROP INDEX CONCURRENTLY`) only if a plan regression is proven.
- **Config:** worker concurrency and flags go back to their pre-release values.
- **Queues:** messages produced by the new version (notifications) stay paused until the old or fixed consumer can handle them, or they go to a parking queue.
- **Validation:** check whether the new rules accepted any registrations the old rules would reject, or the reverse. Include those in the §8 checks.

---

## 7. Data integrity during mitigation and recovery (Task 6)

1. **Writes have one source of truth:** capacity and registration writes only through the DB transaction with a conditional update (`reserved < capacity`). **Never from a cached value.** Cache is turned off for capacity reads during the incident.
2. **No destructive action on in-flight work:** queues are paused, not purged. Messages stay until they're acked by an idempotent consumer. DLQ items are kept for replay.
3. **Idempotency holds under retries:** client idempotency keys and payment-provider idempotency keys stop duplicate charges from the retry storm. The consumer deduplicates on `dedup_key`.
4. **Recovery point:** record a PITR marker / WAL LSN at containment start, and take a logical snapshot of `registrations`, `tracks`, `payments`, `outbox`. This allows comparison and targeted repair, never a blind restore over live data.
5. **Controlled drain:** bring workers back in stages (10 → 20 → 40) with rate limits on the DB, watching DB CPU < 70%. Notifications are drained last, with dedup.
6. **Reads before writes:** run the §8 detection queries **before** re-opening registration and again after the backlog drains.
7. **Repairs are audited:** every correction is a scripted, peer-reviewed transaction that writes an audit row (`actor = incident:INC-REG-001`). No ad-hoc `UPDATE` in the console.
8. **Money is reconciled against the provider:** settlement report vs DB, before any refund or confirmation is changed.

---

## 8. Detecting duplicate registrations and wrong capacity counts (Task 7)

Run on a read replica against the incident window (`11:15` to end of recovery). The same checks run afterwards as a scheduled invariant job. Runnable versions: `02_integrity_checks.sql` (detection) and `03_repair.sql` (audited repair plus the preventive constraints), tested against synthetic incident data in `01_schema_and_incident_data.sql`.

```sql
-- 8.1 Teams with more than one active registration (should return 0 rows)
SELECT team_id, COUNT(*) AS active_regs, array_agg(id) AS reg_ids
FROM registrations
WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED')
GROUP BY team_id HAVING COUNT(*) > 1;

-- 8.2 Capacity counter drift: stored counter vs actual held seats; oversold tracks
SELECT t.id, t.capacity, t.reserved,
       COUNT(r.id) FILTER (WHERE r.seat_held) AS actual_held,
       t.reserved - COUNT(r.id) FILTER (WHERE r.seat_held) AS drift,
       COUNT(r.id) FILTER (WHERE r.seat_held) > t.capacity AS oversold
FROM tracks t LEFT JOIN registrations r ON r.track_id = t.id
GROUP BY t.id, t.capacity, t.reserved
HAVING t.reserved <> COUNT(r.id) FILTER (WHERE r.seat_held)
    OR COUNT(r.id) FILTER (WHERE r.seat_held) > t.capacity;

-- 8.3 Duplicate charges: more than one successful payment per team / registration
SELECT team_id, COUNT(*) AS captured, SUM(amount) AS total
FROM payments
WHERE status = 'succeeded' AND refunded_at IS NULL AND created_at >= '2026-11-21 11:15+05:30'
GROUP BY team_id HAVING COUNT(*) > 1;

-- 8.4 Money without seat / seat without money
SELECT r.id, r.state, p.status
FROM registrations r LEFT JOIN payments p ON p.registration_id = r.id
WHERE (r.state = 'CONFIRMED' AND (p.status IS DISTINCT FROM 'succeeded'))
   OR (r.state IN ('FAILED','CANCELLED') AND p.status = 'succeeded' AND p.refunded_at IS NULL);

-- 8.5 Stuck in-flight work created during the incident
SELECT state, COUNT(*), MIN(updated_at)
FROM registrations
WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN') AND updated_at < now() - interval '15 minutes'
GROUP BY state;

-- 8.6 Duplicate notifications sent
SELECT dedup_key, COUNT(*) FROM notification_deliveries
WHERE sent_at >= '2026-11-21 11:15+05:30'
GROUP BY dedup_key HAVING COUNT(*) > 1;

-- 8.7 Registrations accepted/rejected differently by new validation
SELECT id, team_id, validation_version, validation_result
FROM registrations
WHERE created_at >= '2026-11-21 11:20+05:30' AND validation_version = 'v_new';
-- re-run old rules offline on this set; list the differences
```

**Also check outside the DB:**
- Reconcile the payment-provider settlement report against `payments` for the window (catches charges the DB never recorded).
- Compare cached capacity values against the DB to find any capacity shown or decided from stale cache.
- Look for duplicate idempotency keys with different outcomes.

**Repair rules:**

| Finding | Repair |
|---|---|
| Duplicate active registration | Keep the earliest confirmed one; others → `CANCELLED` with refund |
| Counter drift | Set `reserved = actual_held` in one audited transaction under a row lock |
| Oversold track | Do not cancel automatically. Escalate to the business owner: add capacity, or offer an alternative or refund. Last in, first offered |
| Duplicate charge | Refund the extra charge with the provider idempotency key `refund_<payment_id>` |
| Stuck payment | Run the reconciler (lookup by idempotency key, never re-charge) |
| Duplicate emails | Send no correction unless the content was wrong; record the count for impact |

---

## 9. Recovery plan

| Step | Action | Exit criterion |
|---|---|---|
| R1 | Containment criteria (§5) met for 15 min | Error < 2%, P95 < 1 s, DB CPU < 70% |
| R2 | Run integrity queries §8 (first pass); repair with audited scripts | 8.1–8.4 return 0 rows, or every row has a ticket and an action |
| R3 | Re-open registration at 25% → 50% → 100% of the rate limit | Metrics stay within criteria at each stage for 10 min |
| R4 | Drain the main queue in stages (workers 10 → 20 → 40), oldest first, with dedup | Queue depth trending down; DB CPU < 70% |
| R5 | Resume notifications at a capped rate after the consumer fix is verified in staging | No redelivery loop; no duplicates (8.6) |
| R6 | Second integrity pass §8 and payment reconciliation | All clean, or exceptions owned |
| R7 | Re-introduce the release changes **one at a time** behind flags, with canary and SLO gates (see §11) | Each change soaks 24 h without SLO breach |
| R8 | Close the incident; post-mortem within 48 h | – |

---

## 10. Customer impact

*Exact figures come from the logs after the incident. The method is fixed now so that numbers are comparable.*

| Impact | How measured | Customer action |
|---|---|---|
| Failed or timed-out registration attempts | 5xx and timeouts on `POST /registrations` over the window, deduplicated by team | Email: "Please retry. Your seat was not taken and you were not charged" (only to teams with no successful registration) |
| Slow experience | Requests with P95 > 2 s | None |
| Possible duplicate charges | §8.3 + provider settlement | Proactive refund and apology within 24 h |
| Possible oversold seats | §8.2 | Personal contact from the organiser; extra capacity or full refund |
| Delayed confirmation or notification emails | Queue age of notification messages | Delivered after recovery; status page updated |
| Duplicate emails | §8.6 | Normally none; count recorded |

**Status page:** "Investigating" at 11:35, "Identified / mitigating" once containment works, "Monitoring" after R3, "Resolved" after R6. Updates every 30 minutes. Internal stakeholders (event organisers, support) get the same updates.

---

## 11. Permanent corrective-action plan (Task 8)

| # | Action | Owner | Due | Verification |
|---|---|---|---|---|
| P1 | **Ban bundled releases:** one risky change per deploy; each change behind its own flag; schema migrations ship separately from code | Engineering Manager, Release | 1 week | Release checklist enforced in CI; audit of the next 10 releases |
| P2 | **Progressive delivery:** canary (5%) with automatic rollback on SLO breach (error > 2%, P95 > 1 s, DB CPU > 75%) | Platform / SRE lead | 2 weeks | Game-day: a deliberately bad canary is rolled back automatically in < 5 min |
| P3 | **Worker concurrency guardrails:** concurrency × pods × pool size checked against a DB connection budget; ramp limits (max 2× per change); a separate low-priority DB pool and rate limit for background jobs | Backend lead | 2 weeks | Load test at 10× backlog keeps API P95 < 300 ms; CI rejects configs over budget |
| P4 | **Connection management:** PgBouncer in transaction mode; per-service pool caps; alerts at 70% of pool and `max_connections` | DBA | 2 weeks | Connections can't exceed the budget in a load test; alert fires in staging |
| P5 | **Retry policy standard:** max retries, exponential backoff with jitter, retry budget (≤10% extra load), circuit breakers, `Retry-After` respected; idempotency keys mandatory on mutations | Backend lead | 3 weeks | Chaos test: injected DB latency does not increase total RPS by more than 10% |
| P6 | **Cache safety:** request coalescing (single-flight), TTL jitter, stale-while-revalidate, no caching of capacity or seat writes, key size limits, hit-ratio alerts | Backend lead | 3 weeks | Load test with a mass expiry shows no DB spike > 20%; static check blocks caching on mutation and capacity endpoints |
| P7 | **Query and migration review:** `EXPLAIN` required in PRs for new queries; `CREATE INDEX CONCURRENTLY` only, off-peak, with plan comparison before and after; `statement_timeout` per role; `pg_stat_statements` regression alert | DBA | 2 weeks | CI lint rejects non-concurrent DDL; staging runs the top-20 query plan diff on each migration |
| P8 | **Queue resilience:** consumer contract tests for new message types; poison-message handling to DLQ after N attempts; backlog-age and redelivery-rate alerts; producer rate limits; consumer autoscaling capped by DB budget | Backend / messaging owner | 3 weeks | A test poison message lands in the DLQ without blocking the queue; alert fires within 2 min |
| P9 | **Integrity invariants as monitors:** §8 queries every 5 min, with alerts; DB constraints (partial unique index one-active-registration-per-team, `CHECK reserved <= capacity`) | Data / Backend lead | 1 week | Seeded inconsistency in staging triggers an alert; constraints present in production schema |
| P10 | **Observability:** dashboard per release change; `application_name` set per service; distributed tracing that includes pool-wait and Redis spans; a deploy-marker annotation on every dashboard | SRE lead | 2 weeks | Next incident drill: root-cause signal is found in < 10 min |
| P11 | **Runbook and game-days:** this incident becomes a runbook (containment levers C1–C9 by flag); quarterly game-day | On-call lead | 4 weeks | Game-day completed; time to contain < 15 min |
| P12 | **Capacity load test before releasing high-fan-out features (notifications)** at 2× peak, in production-like staging | QA / Performance | Before re-release of notifications | Test report signed off with SLOs met |

**Post-mortem:** blameless review within 48 h. It confirms the actual root cause(s) against §4.2, records which hypotheses were ruled out and why, and tracks P1–P12 to closure. The incident is closed only when every action is verified.

---

## 12. Template summary (Section G fields)

- **Timeline:** §2
- **Hypotheses:** §4.2 (H1–H8), how to tell them apart in §4.3
- **Evidence:** §4.1 (deployment, metrics, logs, traces, query plans, DB/Redis internals)
- **Containment:** §5 (C1–C9), rollback criteria in §6
- **Recovery:** §7 (integrity), §8 (detection and repair), §9 (staged recovery), §10 (customer impact)
- **Prevention:** §11 (P1–P12 with owners and verification)
- **Verification evidence:** §13

---

## 13. Verification evidence

> **About the screenshots:** each image is a capture of the actual terminal output from running the command shown, on 21 Nov 2026. The footer of each image gives the candidate ID, runtime version and run time. The full text output of the same run is in `expected_output.txt`, so every value in the images can be checked.

The SQL was run end to end on PostgreSQL 16.15 against synthetic data seeded with the damage this incident could cause: a duplicate registration, an oversold track, counter drift, a double charge, a charge on a failed registration, a confirmation with no payment, a stuck payment, and duplicate emails. The reference output from my run is in `expected_output.txt`. All commands are run from inside the `section_g/` folder.

### G1 – Integrity checks BEFORE repair (detection works)
Command: `./run_all.sh` → section `STEP 2`
Expected: 8.1 `TEAM02 {R02,R03}`; 8.2 `TRK-AI oversold = t`, `TRK-WEB drift = 2`; 8.3 `TEAM02 2000`; 8.4 `R06 CHARGED_NOT_REFUNDED`, `R09 CONFIRMED_WITHOUT_PAYMENT`; 8.5 `R07`; 8.6 `email:confirmed:R02 = 3`.

![G1 – checks before repair](screenshots/G1_checks_before.png)

### G2 – Audited repair
Command: `./run_all.sh` → section `STEP 3`
Expected: `COMMIT`, then 5 audit rows (cancel R03, refund P03 and P06, R09 to the reconciler, TRK-WEB counter 3 → 2), all with `actor = oncall:16464`.

![G2 – repair audit trail](screenshots/G2_repair_audit.png)

### G3 – Integrity checks AFTER repair (clean)
Command: `./run_all.sh` → section `STEP 4`
Expected: 8.1–8.4 return `(0 rows)`. 8.5 still lists R07, which is correctly left for the reconciler. 8.6 still lists the 3 sends for R02, which is history recorded for customer impact.

![G3 – checks after repair](screenshots/G3_checks_after.png)

### G4 – Live diagnostics (§3–§4 queries run without errors)
Command: `./run_all.sh` → section `STEP 5`
Expected: D1–D10 all return results (on a quiet demo database most come back empty); D9 shows the query plan; output ends with `######## DONE`.

![G4 – live diagnostics](screenshots/G4_diagnostics.png)
