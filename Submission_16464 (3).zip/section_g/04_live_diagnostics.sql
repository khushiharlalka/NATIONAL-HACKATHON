-- Section G §3-§4 live diagnostics (read-only). Candidate 16464.
-- Run:  psql -d incident_demo -f 04_live_diagnostics.sql
-- Works on any PostgreSQL 13+. pg_stat_statements is used only if installed.

\echo '==== D1 Connections by client and state (pool exhaustion / worker overload)'
SELECT coalesce(nullif(application_name,''),'(unnamed)') AS client, state, COUNT(*) AS sessions
FROM pg_stat_activity WHERE backend_type = 'client backend'
GROUP BY 1, 2 ORDER BY sessions DESC;

\echo '==== D2 Connection headroom'
SELECT COUNT(*) AS used, current_setting('max_connections')::int AS max,
       round(100.0 * COUNT(*) / current_setting('max_connections')::int, 1) AS pct_used
FROM pg_stat_activity;

\echo '==== D3 Active work: CPU-bound vs waiting (CPU saturation vs locks/IO)'
SELECT coalesce(wait_event_type,'CPU (running)') AS waiting_on, COUNT(*) AS sessions
FROM pg_stat_activity WHERE state = 'active' AND pid <> pg_backend_pid()
GROUP BY 1 ORDER BY 2 DESC;

\echo '==== D4 Longest-running queries (slow / unbounded queries)'
SELECT pid, application_name, now() - query_start AS running_for, left(query, 80) AS query
FROM pg_stat_activity
WHERE state = 'active' AND pid <> pg_backend_pid()
ORDER BY running_for DESC NULLS LAST LIMIT 10;

\echo '==== D5 Blocking tree (index migration holding locks?)'
SELECT blocked.pid AS blocked_pid, left(blocked.query, 50) AS blocked_query,
       blocking.pid AS blocking_pid, left(blocking.query, 50) AS blocking_query
FROM pg_stat_activity blocked
JOIN LATERAL unnest(pg_blocking_pids(blocked.pid)) AS b(pid) ON true
JOIN pg_stat_activity blocking ON blocking.pid = b.pid;

\echo '==== D6 Index builds in progress'
SELECT pid, relid::regclass AS table_name, phase, blocks_done, blocks_total
FROM pg_stat_progress_create_index;

\echo '==== D7 Invalid indexes (failed CONCURRENTLY build)'
SELECT indexrelid::regclass AS index_name, indrelid::regclass AS table_name
FROM pg_index WHERE NOT indisvalid;

\echo '==== D8 Sequential-scan heavy tables (missing / unused index)'
SELECT relname, seq_scan, seq_tup_read, idx_scan
FROM pg_stat_user_tables ORDER BY seq_tup_read DESC LIMIT 10;

\echo '==== D9 Query plan for the capacity check (should use an index, not Seq Scan at scale)'
EXPLAIN (ANALYZE, BUFFERS, COSTS OFF)
SELECT COUNT(*) FROM registrations WHERE track_id = 'TRK-AI' AND seat_held;

\echo '==== D10 Top queries by total time (needs pg_stat_statements)'
SELECT CASE WHEN EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_stat_statements')
            THEN 'installed - run: SELECT calls, round(total_exec_time) ms, left(query,80) FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 10;'
            ELSE 'not installed in this demo DB - enable in production (shared_preload_libraries)' END AS pg_stat_statements;
