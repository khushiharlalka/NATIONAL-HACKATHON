"""
Section E - Reliable team registration.

Saga:  reserve seat (local tx)  ->  charge (provider, idempotent, NO tx open)
       ->  confirm + outbox (local tx)  ->  async email / refund via outbox.

Guarantees
  * No oversell        : conditional UPDATE ... WHERE reserved < capacity  + CHECK constraint.
  * No double charge   : client Idempotency-Key -> stored outcome;
                         provider idempotency key = "pay_<registration_id>" (fixed for life).
  * Commit not lost    : response is stored in the same tx as the state change.
  * Reliable email     : transactional outbox, at-least-once dispatch, consumer dedup,
                         provider idempotency key, bounded retries -> dead-letter.
  * Unknown payments   : PAYMENT_UNKNOWN + reconciler + manual review.
  * Auditable          : append-only audit_log row for every transition.

SQLite is used so the tests run anywhere; on PostgreSQL the same SQL works with
SELECT ... FOR UPDATE SKIP LOCKED for the outbox/reconciler claims.
"""
import hashlib
import json
import logging
import sqlite3
import threading
import uuid
from contextlib import contextmanager

log = logging.getLogger("registration")

# --------------------------------------------------------------------------- states
PAYMENT_PENDING = "PAYMENT_PENDING"   # seat held, charge may or may not have been sent
PAYMENT_UNKNOWN = "PAYMENT_UNKNOWN"   # seat held, provider call timed out / errored
MANUAL_REVIEW = "MANUAL_REVIEW"       # seat held, reconciler gave up -> operator
CONFIRMED = "CONFIRMED"               # seat held, money captured
FAILED = "FAILED"                     # seat released, no money (declined / hold expired)
REFUND_PENDING = "REFUND_PENDING"     # seat released, refund command in outbox
REFUNDED = "REFUNDED"                 # terminal

ACTIVE_STATES = (PAYMENT_PENDING, PAYMENT_UNKNOWN, MANUAL_REVIEW, CONFIRMED)

ALLOWED = {
    None: {PAYMENT_PENDING},
    PAYMENT_PENDING: {CONFIRMED, FAILED, PAYMENT_UNKNOWN},
    PAYMENT_UNKNOWN: {CONFIRMED, FAILED, MANUAL_REVIEW},
    MANUAL_REVIEW: {CONFIRMED, FAILED, REFUND_PENDING},
    CONFIRMED: {REFUND_PENDING},
    FAILED: {CONFIRMED, REFUND_PENDING},      # only on a late "succeeded" signal
    REFUND_PENDING: {REFUNDED},
    REFUNDED: set(),
}

# --------------------------------------------------------------------------- config
AMOUNT = 1000
LEASE_SECONDS = 30              # > provider client timeout (10 s)
RECON_GRACE_SECONDS = 60        # leave fresh requests alone
NOT_FOUND_FINAL_AFTER = 900     # provider has no record after 15 min -> hold expired
RECON_MAX_ATTEMPTS = 5          # provider unreachable this many times -> manual review
OUTBOX_MAX_ATTEMPTS = 5         # then dead-letter
OUTBOX_CLAIM_SECONDS = 30
BACKOFF_BASE = 2


# --------------------------------------------------------------------------- errors / test hooks
class SimulatedCrash(Exception):
    """Raised by fault injection to emulate the process dying at a given point."""


class PaymentTimeout(Exception):
    pass


class EmailError(Exception):
    pass


class StaleState(Exception):
    pass


class Faults:
    """One-shot crash points: Faults('after_seat_hold') crashes there once."""

    def __init__(self, *points):
        self.points = set(points)

    def hit(self, point):
        if point in self.points:
            self.points.discard(point)
            raise SimulatedCrash(point)


class Clock:
    def __init__(self, t=1_000_000.0):
        self.t = t

    def now(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


# --------------------------------------------------------------------------- schema
SCHEMA = """
CREATE TABLE IF NOT EXISTS tracks(
  id TEXT PRIMARY KEY,
  capacity INTEGER NOT NULL CHECK (capacity >= 0),
  reserved INTEGER NOT NULL DEFAULT 0,
  CHECK (reserved >= 0 AND reserved <= capacity)          -- DB-enforced: cannot oversell
);
CREATE TABLE IF NOT EXISTS teams(
  id TEXT PRIMARY KEY, email TEXT NOT NULL, payment_method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unregistered'
);
CREATE TABLE IF NOT EXISTS registrations(
  id TEXT PRIMARY KEY,
  team_id TEXT NOT NULL REFERENCES teams(id),
  track_id TEXT NOT NULL REFERENCES tracks(id),
  state TEXT NOT NULL,
  amount INTEGER NOT NULL,
  payment_key TEXT NOT NULL UNIQUE,                        -- provider idempotency key
  charge_id TEXT,
  seat_held INTEGER NOT NULL CHECK (seat_held IN (0,1)),
  lease_owner TEXT, lease_until REAL,
  recon_attempts INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS one_active_registration_per_team
  ON registrations(team_id)
  WHERE state IN ('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED');
CREATE TABLE IF NOT EXISTS idempotency_keys(
  key TEXT PRIMARY KEY, request_hash TEXT NOT NULL, registration_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('IN_PROGRESS','COMPLETED')),
  response_code INTEGER, response_body TEXT,
  created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  dedup_key TEXT NOT NULL UNIQUE,
  topic TEXT NOT NULL, payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING'
         CHECK (status IN ('PENDING','IN_FLIGHT','SENT','DEAD')),
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at REAL NOT NULL, claimed_until REAL, last_error TEXT,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS processed_messages(
  dedup_key TEXT PRIMARY KEY, processed_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity TEXT NOT NULL, entity_id TEXT NOT NULL,
  from_state TEXT, to_state TEXT, event TEXT NOT NULL,
  actor TEXT NOT NULL, correlation_id TEXT, detail TEXT, at REAL NOT NULL
);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
  BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
  BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
"""


def connect(db_path):
    conn = sqlite3.connect(db_path, isolation_level=None, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(db_path):
    conn = connect(db_path)
    conn.executescript(SCHEMA)
    conn.close()


# --------------------------------------------------------------------------- service
class RegistrationService:
    def __init__(self, db_path, payments, clock, faults=None, instance="app-1"):
        self.conn = connect(db_path)
        self.payments = payments
        self.clock = clock
        self.faults = faults or Faults()
        self.instance = instance

    # ---------------------------------------------------------------- tx helpers
    @contextmanager
    def _tx(self):
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            yield self.conn
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise

    def _audit(self, c, entity, entity_id, frm, to, event, actor, cid=None, detail=None):
        now = self.clock.now()
        c.execute(
            "INSERT INTO audit_log(entity,entity_id,from_state,to_state,event,actor,correlation_id,detail,at)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (entity, entity_id, frm, to, event, actor, cid, json.dumps(detail) if detail else None, now),
        )
        log.info(json.dumps({"entity": entity, "id": entity_id, "from": frm, "to": to,
                             "event": event, "actor": actor, "correlation_id": cid, "at": now}))

    def _get_reg(self, c, reg_id):
        return c.execute("SELECT * FROM registrations WHERE id=?", (reg_id,)).fetchone()

    def _transition(self, c, reg, to_state, event, actor, cid, **fields):
        frm = reg["state"]
        if to_state not in ALLOWED[frm]:
            raise StaleState(f"illegal {frm} -> {to_state}")
        sets = "".join(f", {k}=?" for k in fields)
        cur = c.execute(
            f"UPDATE registrations SET state=?, updated_at=?{sets} WHERE id=? AND state=?",
            (to_state, self.clock.now(), *fields.values(), reg["id"], frm),
        )
        if cur.rowcount != 1:                         # optimistic guard
            raise StaleState(f"{reg['id']} no longer {frm}")
        self._audit(c, "registration", reg["id"], frm, to_state, event, actor, cid, fields or None)

    def _release_seat(self, c, reg, actor, cid):
        cur = c.execute("UPDATE registrations SET seat_held=0 WHERE id=? AND seat_held=1", (reg["id"],))
        if cur.rowcount:                               # idempotent release
            c.execute("UPDATE tracks SET reserved=reserved-1 WHERE id=?", (reg["track_id"],))
            self._audit(c, "track", reg["track_id"], None, None, "SEAT_RELEASED", actor, cid,
                        {"registration_id": reg["id"]})

    def _enqueue(self, c, dedup_key, topic, payload):
        c.execute(
            "INSERT OR IGNORE INTO outbox(dedup_key,topic,payload,next_attempt_at,created_at)"
            " VALUES(?,?,?,?,?)",
            (dedup_key, topic, json.dumps(payload), self.clock.now(), self.clock.now()),
        )

    def _complete_new(self, c, key, req_hash, reg_id, code, body):
        now = self.clock.now()
        c.execute(
            "INSERT INTO idempotency_keys(key,request_hash,registration_id,status,response_code,"
            "response_body,created_at,updated_at) VALUES(?,?,?,'COMPLETED',?,?,?,?)",
            (key, req_hash, reg_id, code, json.dumps(body), now, now),
        )
        return code, body

    def _complete_key(self, c, reg_id, code, body):
        c.execute(
            "UPDATE idempotency_keys SET status='COMPLETED', response_code=?, response_body=?,"
            " updated_at=? WHERE registration_id=?",
            (code, json.dumps(body), self.clock.now(), reg_id),
        )

    def _response_for(self, reg_id):
        k = self.conn.execute("SELECT * FROM idempotency_keys WHERE registration_id=?", (reg_id,)).fetchone()
        if k and k["status"] == "COMPLETED":
            return k["response_code"], json.loads(k["response_body"])
        reg = self._get_reg(self.conn, reg_id)
        status = "UNDER_REVIEW" if reg["state"] == MANUAL_REVIEW else "PROCESSING"
        return 202, {"status": status, "registration_id": reg_id}

    # ---------------------------------------------------------------- public API
    def register(self, team_id, track_id, idem_key, correlation_id=None):
        cid = correlation_id or idem_key
        req_hash = hashlib.sha256(f"{team_id}|{track_id}".encode()).hexdigest()
        now = self.clock.now()
        try:
            with self._tx() as c:                                         # ---- Tx1
                k = c.execute("SELECT * FROM idempotency_keys WHERE key=?", (idem_key,)).fetchone()
                if k:
                    if k["request_hash"] != req_hash:
                        return 422, {"status": "IDEMPOTENCY_KEY_REUSED"}
                    if k["status"] == "COMPLETED":
                        return k["response_code"], json.loads(k["response_body"])
                    reg = self._get_reg(c, k["registration_id"])
                    if reg["state"] == MANUAL_REVIEW:
                        return 202, {"status": "UNDER_REVIEW", "registration_id": reg["id"]}
                    if reg["lease_until"] and reg["lease_until"] > now:
                        return 409, {"status": "IN_PROGRESS", "registration_id": reg["id"]}
                    c.execute("UPDATE registrations SET lease_owner=?, lease_until=? WHERE id=?",
                              (self.instance, now + LEASE_SECONDS, reg["id"]))
                    self._audit(c, "registration", reg["id"], reg["state"], reg["state"],
                                "RESUMED_BY_CLIENT_RETRY", self.instance, cid)
                    reg_id = reg["id"]
                else:
                    team = c.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
                    if team is None:
                        return self._complete_new(c, idem_key, req_hash, None, 404, {"status": "TEAM_NOT_FOUND"})
                    if c.execute("SELECT 1 FROM tracks WHERE id=?", (track_id,)).fetchone() is None:
                        return self._complete_new(c, idem_key, req_hash, None, 404, {"status": "TRACK_NOT_FOUND"})
                    active = c.execute(
                        f"SELECT id,state FROM registrations WHERE team_id=? AND state IN "
                        f"({','.join('?' * len(ACTIVE_STATES))})", (team_id, *ACTIVE_STATES)).fetchone()
                    if active:
                        status = "ALREADY_REGISTERED" if active["state"] == CONFIRMED else "REGISTRATION_IN_PROGRESS"
                        return self._complete_new(c, idem_key, req_hash, None, 409,
                                                  {"status": status, "registration_id": active["id"]})
                    cur = c.execute("UPDATE tracks SET reserved=reserved+1 WHERE id=? AND reserved<capacity",
                                    (track_id,))
                    if cur.rowcount == 0:
                        self._audit(c, "track", track_id, None, None, "REJECTED_SOLD_OUT", self.instance, cid,
                                    {"team_id": team_id})
                        return self._complete_new(c, idem_key, req_hash, None, 409, {"status": "SOLD_OUT"})
                    reg_id = "reg_" + uuid.uuid4().hex[:12]
                    c.execute(
                        "INSERT INTO registrations(id,team_id,track_id,state,amount,payment_key,seat_held,"
                        "lease_owner,lease_until,created_at,updated_at) VALUES(?,?,?,?,?,?,1,?,?,?,?)",
                        (reg_id, team_id, track_id, PAYMENT_PENDING, AMOUNT, "pay_" + reg_id,
                         self.instance, now + LEASE_SECONDS, now, now),
                    )
                    c.execute(
                        "INSERT INTO idempotency_keys(key,request_hash,registration_id,status,created_at,updated_at)"
                        " VALUES(?,?,?,'IN_PROGRESS',?,?)", (idem_key, req_hash, reg_id, now, now))
                    self._audit(c, "registration", reg_id, None, PAYMENT_PENDING, "SEAT_HELD", self.instance, cid)
        except sqlite3.IntegrityError:
            # concurrent request for the same team won the partial unique index; nothing committed
            return 409, {"status": "REGISTRATION_IN_PROGRESS"}

        self.faults.hit("after_seat_hold")                                # crash point 1
        return self._charge_and_apply(reg_id, cid, self.instance)

    def _charge_and_apply(self, reg_id, cid, actor):
        reg = self._get_reg(self.conn, reg_id)
        team = self.conn.execute("SELECT payment_method FROM teams WHERE id=?", (reg["team_id"],)).fetchone()
        try:                                               # NO transaction is open here
            res = self.payments.charge(reg["payment_key"], team["payment_method"], reg["amount"])
            outcome, charge_id = res["status"], res.get("charge_id")
        except PaymentTimeout:
            outcome, charge_id = "unknown", None
        self.faults.hit("after_charge_before_commit")                     # crash point 2
        return self.apply_payment_result(reg_id, outcome, charge_id, actor, cid)

    def apply_payment_result(self, reg_id, outcome, charge_id=None, actor="app", cid=None,
                             fail_reason="PAYMENT_DECLINED"):
        """Single entry point for request path, reconciler, webhook and operator."""
        with self._tx() as c:                                             # ---- Tx2
            reg = self._get_reg(c, reg_id)
            st = reg["state"]
            if outcome == "succeeded":
                if st in (PAYMENT_PENDING, PAYMENT_UNKNOWN, MANUAL_REVIEW):
                    self._confirm(c, reg, charge_id, actor, cid)
                elif st == FAILED:
                    self._late_success(c, reg, charge_id, actor, cid)
                # CONFIRMED / REFUND_* : duplicate signal -> no-op
            elif outcome == "declined":
                if st in (PAYMENT_PENDING, PAYMENT_UNKNOWN, MANUAL_REVIEW):
                    self._transition(c, reg, FAILED, fail_reason, actor, cid)
                    self._release_seat(c, reg, actor, cid)
                    code, status = (410, "HOLD_EXPIRED") if fail_reason == "HOLD_EXPIRED" else (402, "PAYMENT_FAILED")
                    self._complete_key(c, reg_id, code, {"status": status, "registration_id": reg_id})
            elif outcome == "unknown":
                if st == PAYMENT_PENDING:
                    self._transition(c, reg, PAYMENT_UNKNOWN, "PAYMENT_OUTCOME_UNKNOWN", actor, cid)
            c.execute("UPDATE registrations SET lease_owner=NULL, lease_until=NULL WHERE id=?", (reg_id,))
            self.faults.hit("inside_commit_tx")                           # crash point 3 (rollback)
        self.faults.hit("after_commit_before_response")                  # crash point 4
        return self._response_for(reg_id)

    def _confirm(self, c, reg, charge_id, actor, cid):
        self._transition(c, reg, CONFIRMED, "PAYMENT_CAPTURED", actor, cid, charge_id=charge_id)
        c.execute("UPDATE teams SET status='registered' WHERE id=?", (reg["team_id"],))
        email = c.execute("SELECT email FROM teams WHERE id=?", (reg["team_id"],)).fetchone()["email"]
        self._enqueue(c, f"email:registration_confirmed:{reg['id']}", "email",
                      {"to": email, "template": "registration_confirmed", "registration_id": reg["id"]})
        self._complete_key(c, reg["id"], 201,
                           {"status": "REGISTERED", "registration_id": reg["id"], "charge_id": charge_id})

    def _late_success(self, c, reg, charge_id, actor, cid):
        """Money arrived after we released the seat. Honour if possible, else refund."""
        c.execute("UPDATE registrations SET charge_id=? WHERE id=?", (charge_id, reg["id"]))
        other = c.execute(
            f"SELECT 1 FROM registrations WHERE team_id=? AND id<>? AND state IN "
            f"({','.join('?' * len(ACTIVE_STATES))})", (reg["team_id"], reg["id"], *ACTIVE_STATES)).fetchone()
        seat = None if other else c.execute(
            "UPDATE tracks SET reserved=reserved+1 WHERE id=? AND reserved<capacity", (reg["track_id"],))
        if seat is not None and seat.rowcount == 1:
            c.execute("UPDATE registrations SET seat_held=1 WHERE id=?", (reg["id"],))
            self._audit(c, "track", reg["track_id"], None, None, "SEAT_REACQUIRED", actor, cid)
            reg = self._get_reg(c, reg["id"])
            self._confirm(c, reg, charge_id, actor, cid)
        else:
            self._transition(c, reg, REFUND_PENDING, "LATE_PAYMENT_NO_SEAT", actor, cid, charge_id=charge_id)
            self._enqueue_refund(c, reg, charge_id)
            self._complete_key(c, reg["id"], 409, {"status": "PAYMENT_REFUNDING", "registration_id": reg["id"]})

    def _enqueue_refund(self, c, reg, charge_id):
        self._enqueue(c, f"refund:{reg['id']}", "refund",
                      {"registration_id": reg["id"], "charge_id": charge_id,
                       "amount": reg["amount"], "refund_key": f"refund_{reg['id']}"})

    def cancel(self, reg_id, actor="team", cid=None):
        """Compensation for a confirmed registration: release seat + refund, atomically queued."""
        with self._tx() as c:
            reg = self._get_reg(c, reg_id)
            if reg["state"] != CONFIRMED:
                return 409, {"status": reg["state"]}
            self._transition(c, reg, REFUND_PENDING, "CANCELLED", actor, cid)
            self._release_seat(c, reg, actor, cid)
            c.execute("UPDATE teams SET status='cancelled' WHERE id=?", (reg["team_id"],))
            self._enqueue_refund(c, reg, reg["charge_id"])
            email = c.execute("SELECT email FROM teams WHERE id=?", (reg["team_id"],)).fetchone()["email"]
            self._enqueue(c, f"email:registration_cancelled:{reg_id}", "email",
                          {"to": email, "template": "registration_cancelled", "registration_id": reg_id})
        return 202, {"status": "REFUND_PENDING", "registration_id": reg_id}

    def mark_refunded(self, reg_id, actor, cid=None):
        with self._tx() as c:
            reg = self._get_reg(c, reg_id)
            if reg["state"] == REFUND_PENDING:
                self._transition(c, reg, REFUNDED, "REFUND_CONFIRMED", actor, cid)

    # ---------------------------------------------------------------- webhook / operator
    def handle_provider_webhook(self, payment_key, status, charge_id=None):
        reg = self.conn.execute("SELECT id FROM registrations WHERE payment_key=?", (payment_key,)).fetchone()
        if reg:
            return self.apply_payment_result(reg["id"], status, charge_id, actor="provider-webhook")

    def resolve_manual_review(self, reg_id, outcome, charge_id, operator):
        return self.apply_payment_result(reg_id, outcome, charge_id, actor=f"operator:{operator}",
                                         fail_reason="OPERATOR_MARKED_FAILED")

    def replay_dead_letter(self, outbox_id, operator):
        with self._tx() as c:
            cur = c.execute("UPDATE outbox SET status='PENDING', attempts=0, next_attempt_at=?, last_error=NULL"
                            " WHERE id=? AND status='DEAD'", (self.clock.now(), outbox_id))
            if cur.rowcount:
                self._audit(c, "outbox", str(outbox_id), "DEAD", "PENDING", "DLQ_REPLAYED", f"operator:{operator}")


# --------------------------------------------------------------------------- reconciler
class Reconciler:
    def __init__(self, svc, instance="recon-1"):
        self.svc, self.instance = svc, instance

    def run_once(self):
        s, now = self.svc, self.svc.clock.now()
        rows = s.conn.execute(
            "SELECT id FROM registrations WHERE state IN (?,?) AND updated_at <= ?"
            " AND (lease_until IS NULL OR lease_until < ?)",
            (PAYMENT_PENDING, PAYMENT_UNKNOWN, now - RECON_GRACE_SECONDS, now)).fetchall()
        for r in rows:
            with s._tx() as c:                       # claim (multi-instance safe)
                cur = c.execute("UPDATE registrations SET lease_owner=?, lease_until=? WHERE id=?"
                                " AND (lease_until IS NULL OR lease_until < ?)",
                                (self.instance, now + LEASE_SECONDS, r["id"], now))
                if cur.rowcount == 0:
                    continue
            reg = s._get_reg(s.conn, r["id"])
            try:
                res = s.payments.lookup(reg["payment_key"])   # query by idempotency key, never re-charge
            except PaymentTimeout:
                res = {"status": "unknown"}
            st = res["status"]
            if st == "succeeded":
                s.apply_payment_result(reg["id"], "succeeded", res["charge_id"], self.instance)
            elif st == "declined":
                s.apply_payment_result(reg["id"], "declined", None, self.instance)
            elif st == "not_found" and now - reg["created_at"] >= NOT_FOUND_FINAL_AFTER:
                s.apply_payment_result(reg["id"], "declined", None, self.instance, fail_reason="HOLD_EXPIRED")
            else:
                self._still_unknown(reg, st)

    def _still_unknown(self, reg, provider_status):
        s = self.svc
        with s._tx() as c:
            reg = s._get_reg(c, reg["id"])
            attempts = reg["recon_attempts"] + (1 if provider_status == "unknown" else 0)
            c.execute("UPDATE registrations SET recon_attempts=?, lease_owner=NULL, lease_until=NULL WHERE id=?",
                      (attempts, reg["id"]))
            if attempts >= RECON_MAX_ATTEMPTS:
                if reg["state"] == PAYMENT_PENDING:
                    s._transition(c, reg, PAYMENT_UNKNOWN, "PAYMENT_OUTCOME_UNKNOWN", self.instance, None)
                    reg = s._get_reg(c, reg["id"])
                s._transition(c, reg, MANUAL_REVIEW, "RECONCILIATION_EXHAUSTED", self.instance, None)
                s._enqueue(c, f"ops:manual_review:{reg['id']}", "ops",
                           {"registration_id": reg["id"], "payment_key": reg["payment_key"]})


# --------------------------------------------------------------------------- outbox dispatcher
class OutboxDispatcher:
    """Relay + consumer. At-least-once; dedup by dedup_key; bounded retries; DLQ."""

    def __init__(self, svc, email_provider, faults=None, instance="worker-1"):
        self.svc, self.email, self.instance = svc, email_provider, instance
        self.faults = faults or Faults()
        self.ops_alerts = []
        self.handlers = {"email": self._send_email, "refund": self._refund, "ops": self._ops}

    def _send_email(self, payload, dedup_key):
        self.email.send(payload["to"], payload["template"], idempotency_key=dedup_key)

    def _refund(self, payload, dedup_key):
        self.svc.payments.refund(payload["refund_key"], payload["charge_id"], payload["amount"])
        self.svc.mark_refunded(payload["registration_id"], actor=self.instance)

    def _ops(self, payload, dedup_key):
        self.ops_alerts.append(payload)

    def run_once(self, limit=50):
        s, now = self.svc, self.svc.clock.now()
        due = ("(status='PENDING' AND next_attempt_at<=?) OR (status='IN_FLIGHT' AND claimed_until<?)")
        rows = s.conn.execute(f"SELECT id FROM outbox WHERE {due} ORDER BY id LIMIT ?", (now, now, limit)).fetchall()
        for r in rows:
            with s._tx() as c:
                cur = c.execute(f"UPDATE outbox SET status='IN_FLIGHT', claimed_until=? WHERE id=? AND ({due})",
                                (now + OUTBOX_CLAIM_SECONDS, r["id"], now, now))
                if cur.rowcount == 0:
                    continue
                msg = c.execute("SELECT * FROM outbox WHERE id=?", (r["id"],)).fetchone()
            if s.conn.execute("SELECT 1 FROM processed_messages WHERE dedup_key=?",
                              (msg["dedup_key"],)).fetchone():
                self._ack(msg, duplicate=True)                # consumer dedup
                continue
            try:
                self.handlers[msg["topic"]](json.loads(msg["payload"]), msg["dedup_key"])
            except SimulatedCrash:
                raise
            except Exception as e:                            # noqa: BLE001
                self._fail(msg, e)
                continue
            self.faults.hit("after_send_before_ack")          # crash point 5
            self._ack(msg)

    def _ack(self, msg, duplicate=False):
        s = self.svc
        with s._tx() as c:
            c.execute("INSERT OR IGNORE INTO processed_messages(dedup_key,processed_at) VALUES(?,?)",
                      (msg["dedup_key"], s.clock.now()))
            c.execute("UPDATE outbox SET status='SENT', claimed_until=NULL WHERE id=?", (msg["id"],))
            s._audit(c, "outbox", str(msg["id"]), msg["status"], "SENT",
                     "DUPLICATE_SKIPPED" if duplicate else "DELIVERED", self.instance, None,
                     {"dedup_key": msg["dedup_key"]})

    def _fail(self, msg, err):
        s = self.svc
        attempts = msg["attempts"] + 1
        with s._tx() as c:
            if attempts >= OUTBOX_MAX_ATTEMPTS:
                c.execute("UPDATE outbox SET status='DEAD', attempts=?, last_error=?, claimed_until=NULL WHERE id=?",
                          (attempts, str(err), msg["id"]))
                s._audit(c, "outbox", str(msg["id"]), "IN_FLIGHT", "DEAD", "DEAD_LETTERED", self.instance, None,
                         {"dedup_key": msg["dedup_key"], "error": str(err)})
            else:
                c.execute("UPDATE outbox SET status='PENDING', attempts=?, last_error=?, next_attempt_at=?,"
                          " claimed_until=NULL WHERE id=?",
                          (attempts, str(err), s.clock.now() + BACKOFF_BASE ** attempts, msg["id"]))
                s._audit(c, "outbox", str(msg["id"]), "IN_FLIGHT", "PENDING", "DELIVERY_FAILED_RETRY",
                         self.instance, None, {"attempt": attempts, "error": str(err)})


# --------------------------------------------------------------------------- fakes (external systems)
class FakePaymentProvider:
    """Behaves like Stripe/Razorpay: same idempotency key -> same charge, never a second one."""

    def __init__(self):
        self.lock = threading.Lock()
        self.charges = {}          # payment_key -> {"status", "charge_id", "amount"}
        self.refunds = {}          # refund_key  -> charge_id
        self.charge_calls = 0
        self.refund_calls = 0
        self.mode = None           # "timeout_before" | "timeout_after" (one-shot)
        self.lookup_unavailable = False
        self.decline_methods = {"pm_declined"}

    def charge(self, key, method, amount):
        with self.lock:
            self.charge_calls += 1
            if self.mode == "timeout_before":
                self.mode = None
                raise PaymentTimeout()
            if key not in self.charges:
                ok = method not in self.decline_methods
                self.charges[key] = {"status": "succeeded" if ok else "declined",
                                     "charge_id": f"ch_{key}" if ok else None, "amount": amount}
            res = dict(self.charges[key])
            if self.mode == "timeout_after":
                self.mode = None
                raise PaymentTimeout()
            return res

    def lookup(self, key):
        if self.lookup_unavailable:
            raise PaymentTimeout()
        with self.lock:
            r = self.charges.get(key)
            return dict(r) if r else {"status": "not_found"}

    def refund(self, refund_key, charge_id, amount):
        with self.lock:
            self.refund_calls += 1
            self.refunds.setdefault(refund_key, charge_id)
            return {"status": "refunded"}

    def force_success(self, key, amount=AMOUNT):
        with self.lock:
            self.charges[key] = {"status": "succeeded", "charge_id": f"ch_{key}", "amount": amount}

    @property
    def captured(self):
        return [k for k, v in self.charges.items() if v["status"] == "succeeded"]


class FakeEmailProvider:
    def __init__(self):
        self.fail_next = 0
        self.calls = 0
        self.delivered = {}        # idempotency_key -> (to, template)

    def send(self, to, template, idempotency_key):
        self.calls += 1
        if self.fail_next > 0:
            self.fail_next -= 1
            raise EmailError("SMTP 503")
        self.delivered.setdefault(idempotency_key, (to, template))
