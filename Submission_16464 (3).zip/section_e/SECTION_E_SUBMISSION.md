# Candidate Submission – Section E: Distributed Transactions

**Candidate ID:** 16464
**Chosen programming language(s):** Python 3.11+ (stdlib only) · SQLite 3 (WAL) for runnable tests; SQL is PostgreSQL-compatible
**Submission repository/path:** `section_e/` → `SECTION_E_SUBMISSION.md`, `registration.py`, `test_registration.py`, `run_demo.py`, `screenshots/`
**Setup command:** `pip install pytest` (no other dependencies; Python 3.11+)
**Test command:** `python -m pytest -v test_registration.py` → **18 passed**
**Demo command:** `python run_demo.py` → mandatory scenario printed step by step, ends `RESULT: PASS`

---

## 0. Design in one paragraph

Treat registration as a **saga with three local steps and no distributed transaction**:
**(Tx1)** hold a seat with a conditional update and create the registration + idempotency record →
**(no tx open)** charge the provider using a *fixed* provider idempotency key `pay_<registration_id>` →
**(Tx2)** apply the result: confirm, store the HTTP response, and write the email to a **transactional outbox**, all in one commit.
Email and refunds are delivered asynchronously by an outbox worker (at-least-once, consumer dedup, bounded retries, DLQ).
Any registration whose payment outcome is unclear is resolved by a **reconciler** that *looks up* the charge by idempotency key and **never re-charges**.
Every state change writes an append-only audit row in the same transaction.

---

## 1. Failure windows in the original code (Task 1)

| # | Window (original code) | What can go wrong | Inconsistent state |
|---|---|---|---|
| W1 | `get_team` → `status == "registered"` check | Two concurrent requests both see "not registered" | Team charged twice |
| W2 | `get_available_seats() > 0` → `decrease_seats()` | Check-then-act race; 2 requests see 1 seat | **Oversold** track |
| W3 | `charge()` call itself | Timeout / 5xx: charge may have succeeded | Money taken, code returns "Registration failed" |
| W4 | `charge()` OK → crash before `decrease_seats` | Nothing recorded locally | **Charged, no seat, no record** |
| W5 | `decrease_seats` → crash before `update_team_status` | Separate writes, no transaction | Seat consumed, team not registered (seat leaked) |
| W6 | Client retry after W3/W4/W5 | No idempotency key; provider key not passed | **Double charge** |
| W7 | `email_service.send()` raises | Exception propagates after DB writes | Registered but client sees 500 → retries → W6 |
| W8 | Email OK → crash before `return "Success"` | Response lost | Client retries → double charge |
| W9 | Email sent synchronously | Blocks request; if inside a tx, holds locks on the seat row | Latency, lock contention, no retry |
| W10 | `payment` falsy (declined) | Nothing to undo here, but no record or audit | Not observable |
| W11 | Seats `> 0` but charge declined/slow | Under concurrency, others are refused while capacity is actually free/held invisibly | Lost sales, no hold expiry |
| W12 | No refund path | Cancellation or late success impossible to compensate | Money held without service |

---

## 2. State machine (Task 2, 6, 8)

```mermaid
stateDiagram-v2
    [*] --> PAYMENT_PENDING: Tx1 seat held (reserved+1 WHERE reserved<capacity)
    [*] --> REJECTED: SOLD_OUT / ALREADY_REGISTERED / NOT_FOUND (stored outcome, no row)

    PAYMENT_PENDING --> CONFIRMED: provider succeeded (Tx2 + outbox email)
    PAYMENT_PENDING --> FAILED: declined → release seat
    PAYMENT_PENDING --> FAILED: reconciler not_found after 15 min (HOLD_EXPIRED) → release seat
    PAYMENT_PENDING --> PAYMENT_UNKNOWN: timeout / 5xx

    PAYMENT_UNKNOWN --> CONFIRMED: reconciler / webhook / client retry: succeeded
    PAYMENT_UNKNOWN --> FAILED: declined / not_found after window
    PAYMENT_UNKNOWN --> MANUAL_REVIEW: 5 lookups failed (ops alert, seat kept)

    MANUAL_REVIEW --> CONFIRMED: operator: succeeded
    MANUAL_REVIEW --> FAILED: operator: no charge
    MANUAL_REVIEW --> REFUND_PENDING: operator: charged but cannot honour

    CONFIRMED --> REFUND_PENDING: cancellation (release seat + refund cmd in same tx)
    FAILED --> CONFIRMED: late success AND seat re-acquired
    FAILED --> REFUND_PENDING: late success AND no seat
    REFUND_PENDING --> REFUNDED: provider refund confirmed (refund_<reg_id> key)
    REFUNDED --> [*]
    FAILED --> [*]
```

**Seat ownership rule:** seat is held in `PAYMENT_PENDING`, `PAYMENT_UNKNOWN`, `MANUAL_REVIEW`, `CONFIRMED`; released (exactly once, guarded by `seat_held` flag) on entry to `FAILED` or `REFUND_PENDING`.
**Illegal transitions** are rejected in code (`ALLOWED` table) and every update is conditional `WHERE id=? AND state=<expected>` (optimistic guard against concurrent workers).

---

## 3. Sequence diagram – happy path and the mandatory failure scenario

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant A as API instance
    participant DB as Database
    participant P as Payment provider
    participant W as Outbox worker
    participant E as Email provider

    C->>A: POST /registrations  Idempotency-Key: K
    A->>DB: Tx1: insert idem K (IN_PROGRESS) + reserved+1 WHERE reserved<capacity + reg PAYMENT_PENDING + lease + audit
    DB-->>A: commit
    A->>P: charge(key=pay_R, ₹1000)   [no DB tx open]
    P-->>A: succeeded ch_1
    A->>DB: Tx2: PENDING→CONFIRMED, team=registered, outbox(email:registration_confirmed:R), idem K=COMPLETED{201,body}, audit
    DB-->>A: commit ✅ (registration durable)
    W->>DB: claim outbox row (PENDING→IN_FLIGHT)
    W->>E: send(idempotency_key=email:registration_confirmed:R)
    E--xW: 503 ❌
    W->>DB: attempts=1, next_attempt_at=now+2s, PENDING, audit DELIVERY_FAILED_RETRY
    Note over A: 💥 API crashes before HTTP response
    Note over A: restart
    C->>A: retry POST, Idempotency-Key: K
    A->>DB: SELECT idem K → COMPLETED
    A-->>C: 201 {REGISTERED, R, ch_1}  (replayed; provider NOT called)
    W->>DB: claim row again (backoff elapsed)
    W->>E: send(same idempotency key)
    E-->>W: 202 delivered
    W->>DB: processed_messages(dedup_key) + SENT + audit DELIVERED
```

### Mandatory scenario – exact state transitions

| Step | Event | registrations | tracks.reserved | idempotency K | outbox email | Provider |
|---|---|---|---|---|---|---|
| 1 | Tx1 commit | `PAYMENT_PENDING`, seat_held=1, lease | 0 → **1** | `IN_PROGRESS` | – | – |
| 2 | charge(`pay_R`) | unchanged | 1 | `IN_PROGRESS` | – | 1 charge `ch_1` |
| 3 | Tx2 commit | **`CONFIRMED`**, charge_id=ch_1 | 1 | **`COMPLETED` {201}** | `PENDING`, attempts 0 | 1 charge |
| 4 | Email 503 | `CONFIRMED` | 1 | `COMPLETED` | `PENDING`, attempts **1**, backoff 2 s | 1 charge |
| 5 | 💥 crash before response | `CONFIRMED` (durable) | 1 | `COMPLETED` | `PENDING` | 1 charge |
| 6 | Restart, client retries with K | no change | 1 | read → replay **201** | `PENDING` | **not called** |
| 7 | Worker retry | no change | 1 | – | `SENT`, processed_messages row | 1 charge, 1 email |

Result: **1 charge, 1 seat, registration preserved, 1 email delivered** (2 send attempts, bounded by 5).
If the client lost K and retries with a new key → `409 ALREADY_REGISTERED` (team-level check + partial unique index), still no charge.
Verified by `test_mandatory_scenario_charge_ok_commit_ok_email_fails_crash_then_retry`.

---

## 4. Recovery strategy

### 4.1 No oversell (Task 2)
- **Conditional update** in Tx1: `UPDATE tracks SET reserved = reserved + 1 WHERE id = ? AND reserved < capacity` → `rowcount = 0` ⇒ `SOLD_OUT`. No read-then-write.
- **DB invariant** as a backstop: `CHECK (reserved >= 0 AND reserved <= capacity)` – even buggy code cannot oversell (`test_db_check_constraint_blocks_oversell_even_if_app_is_buggy`).
- **One active registration per team:** partial unique index on `registrations(team_id) WHERE state IN (PENDING, UNKNOWN, MANUAL_REVIEW, CONFIRMED)`.
- Seat is reserved **before** money is taken, so we never charge for a seat that doesn't exist. Hold release is idempotent (`seat_held` flag).
- Multi-instance safe: all invariants live in the database, not in process memory (20-thread test, capacity 5 → exactly 5 confirmed, 5 charges).

### 4.2 No duplicate payment on retry (Task 3)
Two layers:
1. **Client idempotency key** (`Idempotency-Key` header) → `idempotency_keys` row with `request_hash`.
   - `COMPLETED` → replay stored status + body.
   - `IN_PROGRESS` + live lease → `409 IN_PROGRESS` (prevents two concurrent retries racing).
   - `IN_PROGRESS` + expired lease (previous process died) → take lease and **resume**.
   - Same key, different payload → `422`.
2. **Provider idempotency key** `pay_<registration_id>`, created once in Tx1 and never changed. A resumed request, the reconciler and an operator all reference the *same* key, so the provider returns the original charge instead of creating a new one.
Lease (30 s) > provider client timeout (10 s), so a live request is never treated as dead.

### 4.3 Committed result not lost on crash (Task 4)
The HTTP response body is written to `idempotency_keys` **inside Tx2**, the same commit that confirms the registration. Once Tx2 commits, either the client receives 201 or a retry replays the identical 201. If the crash is *before* Tx2 commits, the tx rolls back atomically and the row stays `PAYMENT_PENDING` – the next retry or the reconciler completes it via provider lookup.

### 4.4 Reliable notification without an open DB tx (Task 5)
- **Transactional outbox:** the email row is inserted in Tx2; it exists iff the registration is confirmed. The DB tx closes before any network I/O.
- **Relay/consumer:** worker claims rows (`PENDING→IN_FLIGHT` with `claimed_until`; `FOR UPDATE SKIP LOCKED` on PostgreSQL), sends, then acks.
- **At-least-once:** a crash after send but before ack leaves the row `IN_FLIGHT`; it is re-claimed after the claim lease expires.
- **Dedup (two places):** `processed_messages(dedup_key)` stops re-processing an acked message; the email provider receives `idempotency_key = dedup_key`, so a resend after a crash is collapsed by the provider.
- **Bounded duplicates:** if the email provider has no idempotency support, the worst case is ≤ `OUTBOX_MAX_ATTEMPTS` (5) sends; in practice only the crash-between-send-and-ack window can duplicate.
- **Retries:** exponential backoff `2^attempt` s; after 5 attempts → `DEAD` (DLQ) + audit `DEAD_LETTERED` + alert. Email failure never changes registration state.
- **Operator recovery:** `replay_dead_letter(outbox_id, operator)` → `PENDING`, attempts reset, audited with operator identity.

### 4.5 Refund and compensation (Task 6)

| Trigger | Compensation (single local tx) | External action |
|---|---|---|
| Payment declined | `→ FAILED`, release seat, store 402 | none |
| Hold expired (provider `not_found` after 15 min) | `→ FAILED (HOLD_EXPIRED)`, release seat, store 410 | none; `pay_R` is retired forever |
| Team cancels before cut-off (policy: full refund up to T-7 days; after that per event T&Cs) | `CONFIRMED → REFUND_PENDING`, release seat, team=`cancelled`, outbox `refund:R` + cancellation email | refund with key `refund_R` |
| **Late success** (webhook/reconciler says succeeded after we marked FAILED) | try re-acquire seat → `CONFIRMED`; if sold out → `REFUND_PENDING` + outbox refund | refund with key `refund_R` |
| Operator: charged but cannot honour | `MANUAL_REVIEW → REFUND_PENDING` | refund |
| Refund confirmed | `REFUND_PENDING → REFUNDED` | – |

Rules: compensation is **semantic** (refund), not rollback; seat release and refund command commit together; refund key is deterministic so a redelivered refund command never refunds twice (`test_cancellation_releases_seat_and_refunds_exactly_once`, `test_late_success_after_hold_expired_and_seat_resold_is_refunded`). A refund that keeps failing goes to the DLQ → finance ops (money owed to a customer is a P1 alert).

---

## 5. Reconciliation strategy (Task 7)

**Scope:** registrations in `PAYMENT_PENDING` or `PAYMENT_UNKNOWN`, older than 60 s, with no live lease. Runs every minute; also triggered by provider webhooks (same `apply_payment_result` entry point, so all paths are idempotent).

```
for reg in due_registrations():                       # claim lease (multi-instance safe)
    res = provider.lookup(idempotency_key = reg.payment_key)    # LOOKUP, never charge
    succeeded            → apply("succeeded")   → CONFIRMED (+ outbox email)
    declined             → apply("declined")    → FAILED, release seat
    not_found & age<15m  → wait (request may still be in flight)
    not_found & age≥15m  → FAILED (HOLD_EXPIRED), release seat, key retired
    timeout / 5xx        → recon_attempts += 1
                           if attempts ≥ 5 → MANUAL_REVIEW + ops alert (seat kept)
```

- **Conservative bias:** while money status is unknown, the seat stays held. Wrongly holding a seat costs a short delay; wrongly releasing it risks overselling or charging for nothing.
- **Why "not_found" needs a window:** the charge request may still be in flight. After 15 min (well above the provider timeout) and with the key retired, a later success is handled by the late-success compensation.
- **Daily settlement reconciliation:** match the provider settlement report to `registrations.charge_id`. Classes: charged but not confirmed → late-success path; confirmed but not charged → ops P1; amount mismatch → ops. Output goes to a reconciliation report and audit.
- **Manual review:** operator checks the provider dashboard and calls `resolve_manual_review(reg, outcome, charge_id, operator)`; the action is audited with the operator's identity.

---

## 6. Observability and audit (Task 8)

| Mechanism | Detail |
|---|---|
| **Append-only audit log** | Row per transition: `entity, entity_id, from_state, to_state, event, actor, correlation_id, detail, at`, written **in the same tx** as the change (no transition without an audit row). DB triggers block `UPDATE`/`DELETE`. In production, also stream to WORM storage. |
| **Correlation** | `correlation_id` = client idempotency key, propagated to provider metadata, outbox payload and logs → one key traces request → charge → email → refund. |
| **Structured logs** | JSON line per transition (same fields as audit). |
| **Metrics** | Counters: transitions by `from→to`, sold-out rejects, idempotent replays, outbox retries, DLQ size. Gauges: rows in `PAYMENT_UNKNOWN`, `MANUAL_REVIEW`, `REFUND_PENDING`; oldest-pending age; `capacity - reserved` per track. |
| **Alerts** | DLQ > 0; `MANUAL_REVIEW` > 0; `PAYMENT_UNKNOWN` older than 10 min; refund pending > 1 h; reconciliation mismatch > 0; invariant check `reserved ≠ count(seat_held)`. |
| **Tracing** | OpenTelemetry span per step (Tx1, charge, Tx2, dispatch) with `registration_id`. |
| **Invariant job** | Periodic SQL: `reserved = Σ seat_held ≤ capacity`; `captured − refunded = confirmed`; ≤ 1 active registration per team (same checks as `assert_invariants()` in the tests). |

---

## 7. Pseudocode (implementation: `registration.py`)

```python
def register(team, track, K):
    with tx():                                                   # Tx1
        k = idem.get(K)
        if k: if k.hash != h(team,track): return 422
              if k.COMPLETED: return k.stored_response           # replay
              if lease_live(k.reg): return 409 IN_PROGRESS
              take_lease(k.reg); reg = k.reg                     # resume after crash
        else:
              if team has active reg: store+return 409 ALREADY_REGISTERED
              if UPDATE tracks SET reserved=reserved+1 WHERE id=track AND reserved<capacity == 0:
                  store+return 409 SOLD_OUT
              reg = insert(state=PAYMENT_PENDING, payment_key="pay_"+id, seat_held=1, lease)
              idem.insert(K, IN_PROGRESS, reg); audit(None→PAYMENT_PENDING)
    try:    res = provider.charge(idempotency_key=reg.payment_key, amount)   # no tx open
    except Timeout: res = UNKNOWN
    return apply_payment_result(reg, res)

def apply_payment_result(reg, res):        # used by request, reconciler, webhook, operator
    with tx():                                                   # Tx2
        if res==SUCCEEDED and reg in (PENDING,UNKNOWN,REVIEW):
            transition(→CONFIRMED); team.registered
            outbox.add("email:registration_confirmed:"+reg.id)
            idem.complete(201, body)
        elif res==SUCCEEDED and reg==FAILED: late_success()      # re-seat or refund
        elif res==DECLINED and reg in (PENDING,UNKNOWN,REVIEW):
            transition(→FAILED); release_seat(); idem.complete(402)
        elif res==UNKNOWN and reg==PENDING: transition(→PAYMENT_UNKNOWN)
        clear_lease()
    return stored_response_or_202(reg)
```

---

## 8. Tests – crash and failure points (`test_registration.py`, 18 passing)

Fault injection: `Faults("point")` raises `SimulatedCrash` once at a named point; a "restart" is a new service object on the same database file; payment/email fakes are external and survive restarts. Every test ends with `assert_invariants()` (no oversell, seat counter = held seats, captured − refunded = confirmed, ≤ 1 active registration per team).

| # | Crash / failure point | Test | Asserts |
|---|---|---|---|
| 1 | **Mandatory:** charge OK → commit OK → email 503 → crash before response → retry | `test_mandatory_scenario_…` | 201 replayed, provider called once, 1 seat, 1 email after retry |
| 2 | Crash after seat hold, before charge | `test_crash_after_seat_hold_…` | live lease → 409; after expiry retry resumes → 1 charge |
| 3 | Crash after provider charged, before DB commit | `test_crash_after_charge_before_commit_…` | 2 provider calls, **1 capture** (provider idempotency) |
| 4 | Crash inside Tx2 (rollback) and client never returns | `test_crash_during_commit_rolls_back_…` | no outbox row for uncommitted state; reconciler confirms via lookup, no re-charge |
| 5 | Crash after email sent, before ack; plus broker redelivery | `test_crash_after_email_sent_before_ack_…` | 1 delivered email; duplicate skipped by consumer dedup |
| 6 | Provider timeout after charging (outcome unknown) | `test_payment_timeout_unknown_resolved_by_reconciler` | 202 PROCESSING, seat held, reconciler → CONFIRMED |
| 7 | Provider unreachable for reconciliation | `test_unknown_too_long_goes_to_manual_review_…` | MANUAL_REVIEW after 5 tries, ops alert, operator resolves (audited) |
| 8 | Abandoned hold (crash, no retry) | `test_abandoned_hold_released_only_after_…` | not released at 60 s; released at 15 min; old key → 410, never charged |
| 9 | Payment declined | `test_declined_payment_releases_seat_…` | seat freed, stored 402 on retry, freed seat reusable |
| 10 | Email permanently failing | `test_email_permanent_failure_dead_letters_…` | exactly 5 attempts → DEAD; registration untouched; operator replay delivers once |
| 11 | 20 concurrent teams, capacity 5 | `test_no_oversell_under_concurrent_requests` | 5 × 201, 15 × SOLD_OUT, 5 charges |
| 12 | Buggy code bypassing the app | `test_db_check_constraint_blocks_oversell_…` | CHECK constraint rejects |
| 13 | Same team, 10 parallel requests, different keys | `test_same_team_concurrent_requests_…` | 1 × 201, 1 charge |
| 14 | Late success after hold expired and seat resold | `test_late_success_after_hold_expired_…` | REFUND_PENDING → REFUNDED, 1 refund, B keeps seat |
| 15 | Cancellation with repeated worker runs | `test_cancellation_releases_seat_…` | seat released, 1 refund, 2 distinct emails |
| 16 | Key reuse with different payload | `test_same_key_different_payload_rejected` | 422 |
| 17 | Retry with new key after success | `test_retry_with_new_key_after_success_…` | 409 ALREADY_REGISTERED, no charge |
| 18 | Audit tampering | `test_audit_log_is_append_only_and_complete` | full transition chain + correlation id; UPDATE/DELETE blocked |

---

## 9. Trade-offs, assumptions and known limitations

- **Reserve-then-charge vs charge-then-reserve:** reserving first means we never take money for a non-existent seat; the cost is short holds during payment (bounded by lease + reconciler). Chosen deliberately.
- **Honour vs refund on late success:** we honour it if a seat is still free (better customer outcome), otherwise refund. A stricter "always refund" policy is simpler; it's a one-line change.
- **Assumption:** the payment provider supports idempotency keys and lookup by key (Stripe, Razorpay, Adyen do). If not, store our own `merchant_order_id` and reconcile by it.
- **Assumption:** the email provider accepts an idempotency key; without it, duplicates are bounded to the crash-between-send-and-ack window (≤ 5 total).
- **SQLite in tests:** `BEGIN IMMEDIATE` serialises writers; on PostgreSQL use `READ COMMITTED` + the same conditional updates, and `FOR UPDATE SKIP LOCKED` for outbox/reconciler claims. A message broker (Kafka/SQS) can replace polling; dedup stays on `dedup_key`.
- **Hot track contention:** one counter row per track serialises writers; at very high scale, shard capacity into N bucket rows or pre-allocate seat rows (`UPDATE seats SET reg=? WHERE track=? AND reg IS NULL LIMIT 1`).
- **Not implemented:** HTTP layer, auth, refund cut-off date logic, settlement-file reconciliation job (designed in §5, not coded).

---

## 10. Verification evidence

> **About the screenshots:** each image is a capture of the actual terminal output from running the command shown, on 21 Nov 2026. The footer of each image gives the candidate ID, runtime version and run time. The full text output of the same run is in `test_output.txt` and `demo_output.txt`, so every value in the images can be checked.

All commands are run from inside the `section_e/` folder. Reference outputs from my run are in `test_output.txt` and `demo_output.txt`.

### E1 – Test suite (18 crash/failure tests)
Command: `python -m pytest -v test_registration.py`
Expected: 18 lines ending `PASSED`, last line `18 passed`.

![E1 – pytest 18 passed](screenshots/E1_pytest.png)

### E2 – Mandatory scenario: crash, email failure, client retry
Command: `python run_demo.py` (top half of the output)
Expected: `after crash` shows `CONFIRMED`, `reserved 1/1`, `COMPLETED stored_code=201`; the retry returns `HTTP 201` with `charge calls=1`.

![E2 – demo crash and retry](screenshots/E2_demo_retry.png)

### E3 – Mandatory scenario: final state and audit trail
Command: `python run_demo.py` (bottom half of the output)
Expected: `final` shows `outbox email SENT`, `delivered=1`, `captured=1`; audit trail has 4 rows; last line `RESULT: PASS - 1 charge, 1 seat, registration kept, 1 email`.

![E3 – demo final state and audit](screenshots/E3_demo_result.png)
