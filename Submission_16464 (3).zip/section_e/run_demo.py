"""
Section E - mandatory failure scenario, printed step by step.
Run:  python run_demo.py
"""
import json
import os
import tempfile

from registration import (Clock, FakeEmailProvider, FakePaymentProvider, Faults, OutboxDispatcher,
                          RegistrationService, SimulatedCrash, connect, init_db)


def snapshot(db, pay, email, label):
    c = connect(db)
    reg = c.execute("SELECT id, state, seat_held, charge_id FROM registrations").fetchone()
    trk = c.execute("SELECT capacity, reserved FROM tracks").fetchone()
    key = c.execute("SELECT status, response_code FROM idempotency_keys").fetchone()
    ob = c.execute("SELECT status, attempts FROM outbox").fetchone()
    c.close()
    print(f"\n--- {label}")
    print(f"  registration   : {reg['state'] if reg else '-'}  seat_held={reg['seat_held'] if reg else '-'}")
    print(f"  track          : reserved {trk['reserved']}/{trk['capacity']}")
    print(f"  idempotency key: {key['status'] if key else '-'}  stored_code={key['response_code'] if key else '-'}")
    print(f"  outbox email   : {ob['status'] + ' attempts=' + str(ob['attempts']) if ob else '-'}")
    print(f"  provider       : charge calls={pay.charge_calls}  captured={len(pay.captured)}")
    print(f"  email provider : send calls={email.calls}  delivered={len(email.delivered)}")


def main():
    db = os.path.join(tempfile.mkdtemp(), "demo.db")
    init_db(db)
    c = connect(db)
    c.execute("INSERT INTO tracks(id,capacity) VALUES('T1',1)")
    c.execute("INSERT INTO teams(id,email,payment_method) VALUES('A','a@x.in','pm_ok')")
    c.close()
    clock, pay, email = Clock(), FakePaymentProvider(), FakeEmailProvider()

    print("=" * 66)
    print(" SECTION E - MANDATORY FAILURE SCENARIO (Candidate 16464)")
    print("=" * 66)

    svc = RegistrationService(db, pay, clock, Faults("after_commit_before_response"))
    worker = OutboxDispatcher(svc, email)
    email.fail_next = 1
    try:
        svc.register("A", "T1", "key-1")
    except SimulatedCrash as e:
        print(f"\n[1-3] charge OK -> DB commit OK -> CRASH before response ({e})")
    snapshot(db, pay, email, "after crash")

    worker.run_once()
    print("\n[4] email provider returned 503")
    snapshot(db, pay, email, "after email failure")

    print("\n[5] process restarts; client retries with SAME idempotency key")
    svc2 = RegistrationService(db, pay, clock)
    code, body = svc2.register("A", "T1", "key-1")
    print(f"  response -> HTTP {code} {json.dumps(body)}")
    snapshot(db, pay, email, "after client retry")

    clock.advance(10)
    OutboxDispatcher(svc2, email).run_once()
    OutboxDispatcher(svc2, email).run_once()
    print("\n[6] outbox worker retries after backoff")
    snapshot(db, pay, email, "final")

    c = connect(db)
    print("\nAudit trail:")
    for r in c.execute("SELECT entity, from_state, to_state, event, actor FROM audit_log ORDER BY id"):
        print(f"  {r['entity']:<13} {str(r['from_state']):<16} -> {str(r['to_state']):<16} {r['event']:<24} {r['actor']}")
    c.close()

    ok = (pay.charge_calls == 1 and len(pay.captured) == 1 and len(email.delivered) == 1 and code == 201)
    print("\nRESULT:", "PASS - 1 charge, 1 seat, registration kept, 1 email" if ok else "FAIL")


if __name__ == "__main__":
    main()
