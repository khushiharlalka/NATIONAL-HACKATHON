"""
Crash / failure-point tests for Section E.   Run:  python -m pytest -v test_registration.py

"Restart" = a brand-new service object on the same database file. The fake payment and
email providers are external systems, so they survive the restart.
"""
import sqlite3
from concurrent.futures import ThreadPoolExecutor

import pytest

from registration import (
    CONFIRMED, FAILED, MANUAL_REVIEW, PAYMENT_PENDING, PAYMENT_UNKNOWN, REFUNDED,
    LEASE_SECONDS, NOT_FOUND_FINAL_AFTER, OUTBOX_MAX_ATTEMPTS, RECON_GRACE_SECONDS, RECON_MAX_ATTEMPTS,
    Clock, FakeEmailProvider, FakePaymentProvider, Faults, OutboxDispatcher, Reconciler,
    RegistrationService, SimulatedCrash, connect, init_db,
)


# --------------------------------------------------------------------------- harness
class Env:
    def __init__(self, tmp_path, capacity=1, teams=("A", "B")):
        self.db = str(tmp_path / "reg.db")
        init_db(self.db)
        c = connect(self.db)
        c.execute("INSERT INTO tracks(id,capacity) VALUES('T1',?)", (capacity,))
        for t in teams:
            pm = "pm_declined" if t == "DECLINE" else "pm_ok"
            c.execute("INSERT INTO teams(id,email,payment_method) VALUES(?,?,?)", (t, f"{t}@x.in", pm))
        c.close()
        self.clock, self.pay, self.email = Clock(), FakePaymentProvider(), FakeEmailProvider()

    def boot(self, *faults, worker_faults=()):
        svc = RegistrationService(self.db, self.pay, self.clock, Faults(*faults))
        return svc, OutboxDispatcher(svc, self.email, Faults(*worker_faults)), Reconciler(svc)

    def q(self, sql, *args):
        c = connect(self.db)
        try:
            return c.execute(sql, args).fetchall()
        finally:
            c.close()

    def reg(self, team="A"):
        return self.q("SELECT * FROM registrations WHERE team_id=? ORDER BY created_at DESC", team)[0]

    def reserved(self):
        return self.q("SELECT reserved FROM tracks WHERE id='T1'")[0]["reserved"]

    def events(self, reg_id):
        return [r["event"] for r in self.q(
            "SELECT event FROM audit_log WHERE entity='registration' AND entity_id=? ORDER BY id", reg_id)]

    def assert_invariants(self):
        t = self.q("SELECT capacity, reserved FROM tracks WHERE id='T1'")[0]
        held = self.q("SELECT COUNT(*) n FROM registrations WHERE track_id='T1' AND seat_held=1")[0]["n"]
        assert t["reserved"] == held <= t["capacity"], "seat counter drifted / oversold"
        confirmed = self.q("SELECT COUNT(*) n FROM registrations WHERE state='CONFIRMED'")[0]["n"]
        captured_not_refunded = len(self.pay.captured) - len(self.pay.refunds)
        assert captured_not_refunded == confirmed, "money taken without a confirmed seat (or vice versa)"
        for row in self.q("SELECT team_id, COUNT(*) n FROM registrations WHERE state IN "
                          "('PAYMENT_PENDING','PAYMENT_UNKNOWN','MANUAL_REVIEW','CONFIRMED') GROUP BY team_id"):
            assert row["n"] == 1


@pytest.fixture
def env(tmp_path):
    return Env(tmp_path)


# --------------------------------------------------------------------------- 1. MANDATORY SCENARIO
def test_mandatory_scenario_charge_ok_commit_ok_email_fails_crash_then_retry(env):
    svc, worker, _ = env.boot("after_commit_before_response")
    env.email.fail_next = 1

    with pytest.raises(SimulatedCrash):                      # crash before HTTP response
        svc.register("A", "T1", "key-1")
    r = env.reg()
    assert r["state"] == CONFIRMED and env.reserved() == 1 and len(env.pay.captured) == 1

    worker.run_once()                                        # email provider fails
    ob = env.q("SELECT * FROM outbox")[0]
    assert ob["status"] == "PENDING" and ob["attempts"] == 1 and env.email.delivered == {}

    svc2, worker2, _ = env.boot()                            # ---- restart
    code, body = svc2.register("A", "T1", "key-1")           # client retry, same key
    assert code == 201 and body["registration_id"] == r["id"]
    assert env.pay.charge_calls == 1                         # provider not even called again

    env.clock.advance(10)                                    # past backoff
    worker2.run_once()
    worker2.run_once()
    assert len(env.email.delivered) == 1 and env.email.calls == 2
    assert env.events(r["id"]) == ["SEAT_HELD", "PAYMENT_CAPTURED"]
    env.assert_invariants()


# --------------------------------------------------------------------------- 2. crash after seat hold
def test_crash_after_seat_hold_before_charge_retry_resumes_single_charge(env):
    svc, _, _ = env.boot("after_seat_hold")
    with pytest.raises(SimulatedCrash):
        svc.register("A", "T1", "key-1")
    assert env.reg()["state"] == PAYMENT_PENDING and env.pay.charge_calls == 0

    svc2, _, _ = env.boot()
    assert svc2.register("A", "T1", "key-1")[0] == 409       # lease of dead process still live
    env.clock.advance(LEASE_SECONDS + 1)
    code, _ = svc2.register("A", "T1", "key-1")
    assert code == 201 and len(env.pay.captured) == 1
    assert "RESUMED_BY_CLIENT_RETRY" in env.events(env.reg()["id"])
    env.assert_invariants()


# --------------------------------------------------------------------------- 3. crash after charge, before commit
def test_crash_after_charge_before_commit_no_double_charge(env):
    svc, _, _ = env.boot("after_charge_before_commit")
    with pytest.raises(SimulatedCrash):
        svc.register("A", "T1", "key-1")
    assert env.reg()["state"] == PAYMENT_PENDING and len(env.pay.captured) == 1   # money taken, DB unaware

    env.clock.advance(LEASE_SECONDS + 1)
    svc2, _, _ = env.boot()
    code, body = svc2.register("A", "T1", "key-1")
    assert code == 201
    assert env.pay.charge_calls == 2 and len(env.pay.captured) == 1               # provider dedup by key
    env.assert_invariants()


# --------------------------------------------------------------------------- 4. crash inside commit tx (rollback)
def test_crash_during_commit_rolls_back_then_reconciler_recovers_without_client(env):
    svc, worker, _ = env.boot("inside_commit_tx")
    with pytest.raises(SimulatedCrash):
        svc.register("A", "T1", "key-1")
    assert env.reg()["state"] == PAYMENT_PENDING              # tx rolled back
    assert env.q("SELECT COUNT(*) n FROM outbox")[0]["n"] == 0  # no email queued for an uncommitted state

    env.clock.advance(RECON_GRACE_SECONDS + 1)
    svc2, worker2, recon = env.boot()
    recon.run_once()                                         # client never came back
    assert env.reg()["state"] == CONFIRMED and env.pay.charge_calls == 1   # lookup, not re-charge
    worker2.run_once()
    assert len(env.email.delivered) == 1
    assert svc2.register("A", "T1", "key-1")[0] == 201        # late retry sees stored outcome
    env.assert_invariants()


# --------------------------------------------------------------------------- 5. crash after email sent, before ack
def test_crash_after_email_sent_before_ack_no_duplicate_delivery(env):
    svc, worker, _ = env.boot(worker_faults=("after_send_before_ack",))
    assert svc.register("A", "T1", "key-1")[0] == 201
    with pytest.raises(SimulatedCrash):
        worker.run_once()
    assert env.q("SELECT status FROM outbox")[0]["status"] == "IN_FLIGHT"

    env.clock.advance(31)                                    # claim expires
    _, worker2, _ = env.boot()
    worker2.run_once()                                       # redelivered (at-least-once)
    assert env.email.calls == 2 and len(env.email.delivered) == 1   # provider idempotency key

    # broker-style redelivery of an already-acked message -> consumer dedup, handler not called
    c = connect(env.db)
    c.execute("UPDATE outbox SET status='PENDING'")
    c.close()
    worker2.run_once()
    assert env.email.calls == 2
    assert env.q("SELECT COUNT(*) n FROM audit_log WHERE event='DUPLICATE_SKIPPED'")[0]["n"] == 1
    env.assert_invariants()


# --------------------------------------------------------------------------- 6. provider timeout after charging
def test_payment_timeout_unknown_resolved_by_reconciler(env):
    env.pay.mode = "timeout_after"                           # provider charged, response lost
    svc, _, recon = env.boot()
    code, body = svc.register("A", "T1", "key-1")
    assert code == 202 and body["status"] == "PROCESSING"
    assert env.reg()["state"] == PAYMENT_UNKNOWN and env.reserved() == 1   # seat stays held

    env.clock.advance(RECON_GRACE_SECONDS + 1)
    recon.run_once()
    assert env.reg()["state"] == CONFIRMED and env.pay.charge_calls == 1
    assert svc.register("A", "T1", "key-1")[0] == 201
    env.assert_invariants()


# --------------------------------------------------------------------------- 7. provider unreachable -> manual review
def test_unknown_too_long_goes_to_manual_review_operator_resolves(env):
    env.pay.mode = "timeout_before"                          # nothing charged
    env.pay.lookup_unavailable = True
    svc, worker, recon = env.boot()
    svc.register("A", "T1", "key-1")
    for _ in range(RECON_MAX_ATTEMPTS):
        env.clock.advance(RECON_GRACE_SECONDS + 1)
        recon.run_once()
    r = env.reg()
    assert r["state"] == MANUAL_REVIEW and env.reserved() == 1        # conservative: seat kept
    assert svc.register("A", "T1", "key-1") == (202, {"status": "UNDER_REVIEW", "registration_id": r["id"]})
    worker.run_once()
    assert worker.ops_alerts and worker.ops_alerts[0]["registration_id"] == r["id"]

    svc.resolve_manual_review(r["id"], "declined", None, operator="rajev")   # checked provider dashboard
    assert env.reg()["state"] == FAILED and env.reserved() == 0
    assert "OPERATOR_MARKED_FAILED" in env.events(r["id"])
    env.assert_invariants()


# --------------------------------------------------------------------------- 8. abandoned hold
def test_abandoned_hold_released_only_after_provider_says_not_found(env):
    svc, _, recon = env.boot("after_seat_hold")
    with pytest.raises(SimulatedCrash):
        svc.register("A", "T1", "key-1")
    env.clock.advance(RECON_GRACE_SECONDS + 1)
    recon.run_once()
    assert env.reg()["state"] == PAYMENT_PENDING             # too early to give up
    env.clock.advance(NOT_FOUND_FINAL_AFTER)
    recon.run_once()
    assert env.reg()["state"] == FAILED and env.reserved() == 0
    svc2, _, _ = env.boot()
    assert svc2.register("A", "T1", "key-1")[0] == 410       # HOLD_EXPIRED, never charged with old key
    assert env.pay.charge_calls == 0
    env.assert_invariants()


# --------------------------------------------------------------------------- 9. declined
def test_declined_payment_releases_seat_and_retry_returns_stored_failure(tmp_path):
    env = Env(tmp_path, capacity=1, teams=("DECLINE", "B"))
    svc, _, _ = env.boot()
    assert svc.register("DECLINE", "T1", "k1")[0] == 402
    assert env.reserved() == 0
    assert svc.register("DECLINE", "T1", "k1")[0] == 402 and env.pay.charge_calls == 1
    assert svc.register("B", "T1", "k2")[0] == 201           # freed seat is usable
    env.assert_invariants()


# --------------------------------------------------------------------------- 10. email DLQ + operator replay
def test_email_permanent_failure_dead_letters_and_operator_replays(env):
    env.email.fail_next = 100
    svc, worker, _ = env.boot()
    svc.register("A", "T1", "key-1")
    for _ in range(OUTBOX_MAX_ATTEMPTS + 3):
        worker.run_once()
        env.clock.advance(100)
    ob = env.q("SELECT * FROM outbox")[0]
    assert ob["status"] == "DEAD" and env.email.calls == OUTBOX_MAX_ATTEMPTS   # bounded attempts
    assert env.reg()["state"] == CONFIRMED                   # email failure never undoes registration

    env.email.fail_next = 0
    svc.replay_dead_letter(ob["id"], operator="ops")
    worker.run_once()
    worker.run_once()
    assert len(env.email.delivered) == 1
    env.assert_invariants()


# --------------------------------------------------------------------------- 11. concurrency / oversell
def test_no_oversell_under_concurrent_requests(tmp_path):
    teams = [f"T{i:02d}" for i in range(20)]
    env = Env(tmp_path, capacity=5, teams=teams)

    def go(team):
        svc = RegistrationService(env.db, env.pay, env.clock)     # one connection per "instance"
        return svc.register(team, "T1", f"key-{team}")[0]

    with ThreadPoolExecutor(max_workers=20) as ex:
        codes = list(ex.map(go, teams))
    assert codes.count(201) == 5 and codes.count(409) == 15
    assert env.reserved() == 5 and len(env.pay.captured) == 5
    env.assert_invariants()


def test_db_check_constraint_blocks_oversell_even_if_app_is_buggy(env):
    c = connect(env.db)
    c.execute("UPDATE tracks SET reserved=capacity")
    with pytest.raises(sqlite3.IntegrityError):
        c.execute("UPDATE tracks SET reserved=reserved+1")
    c.close()


def test_same_team_concurrent_requests_different_keys_single_charge(env):
    def go(k):
        return RegistrationService(env.db, env.pay, env.clock).register("A", "T1", k)[0]

    with ThreadPoolExecutor(max_workers=10) as ex:
        codes = list(ex.map(go, [f"k{i}" for i in range(10)]))
    assert codes.count(201) == 1 and len(env.pay.captured) == 1
    env.assert_invariants()


# --------------------------------------------------------------------------- 12. compensation
def test_late_success_after_hold_expired_and_seat_resold_is_refunded(env):
    svc, worker, recon = env.boot("after_seat_hold")
    with pytest.raises(SimulatedCrash):
        svc.register("A", "T1", "key-A")
    a = env.reg("A")
    env.clock.advance(NOT_FOUND_FINAL_AFTER + RECON_GRACE_SECONDS)
    recon.run_once()
    assert svc.register("B", "T1", "key-B")[0] == 201        # B takes the only seat

    env.pay.force_success(a["payment_key"])                  # in-flight charge lands late
    svc.handle_provider_webhook(a["payment_key"], "succeeded", f"ch_{a['payment_key']}")
    assert env.reg("A")["state"] == "REFUND_PENDING"
    worker.run_once()
    worker.run_once()
    assert env.reg("A")["state"] == REFUNDED and env.pay.refund_calls == 1
    assert svc.register("A", "T1", "key-A")[1]["status"] == "PAYMENT_REFUNDING"
    env.assert_invariants()


def test_cancellation_releases_seat_and_refunds_exactly_once(env):
    svc, worker, _ = env.boot()
    _, body = svc.register("A", "T1", "key-1")
    svc.cancel(body["registration_id"])
    assert env.reserved() == 0
    for _ in range(3):
        worker.run_once()
    assert env.reg()["state"] == REFUNDED and len(env.pay.refunds) == 1
    templates = sorted(t for _, t in env.email.delivered.values())
    assert templates == ["registration_cancelled", "registration_confirmed"]
    env.assert_invariants()


# --------------------------------------------------------------------------- 13. idempotency edge cases
def test_same_key_different_payload_rejected(env):
    svc, _, _ = env.boot()
    svc.register("A", "T1", "key-1")
    assert svc.register("B", "T1", "key-1")[0] == 422


def test_retry_with_new_key_after_success_does_not_charge(env):
    svc, _, _ = env.boot()
    svc.register("A", "T1", "key-1")
    code, body = svc.register("A", "T1", "key-2")            # client lost its key
    assert code == 409 and body["status"] == "ALREADY_REGISTERED" and env.pay.charge_calls == 1


# --------------------------------------------------------------------------- 14. audit
def test_audit_log_is_append_only_and_complete(env):
    svc, worker, _ = env.boot()
    _, body = svc.register("A", "T1", "key-1")
    worker.run_once()
    rows = env.q("SELECT * FROM audit_log WHERE entity_id=? ORDER BY id", body["registration_id"])
    assert [(r["from_state"], r["to_state"]) for r in rows] == [(None, "PAYMENT_PENDING"),
                                                                ("PAYMENT_PENDING", "CONFIRMED")]
    assert all(r["actor"] and r["correlation_id"] == "key-1" for r in rows)
    c = connect(env.db)
    with pytest.raises(sqlite3.DatabaseError):
        c.execute("DELETE FROM audit_log")
    with pytest.raises(sqlite3.DatabaseError):
        c.execute("UPDATE audit_log SET actor='x'")
    c.close()
